<?php

use App\Http\Controllers\Admin\BookingController;
use App\Http\Controllers\Admin\CalendarController;
use App\Http\Controllers\Admin\ContactMessageController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\GalleryItemController;
use App\Http\Controllers\Admin\MasterController;
use App\Http\Controllers\Admin\ReviewController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\ServiceCategoryController;
use App\Http\Controllers\Admin\ServiceController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\UserController;
use Illuminate\Support\Facades\Route;

// Доступ к разделу /admin — только для ролей admin и manager (client сюда не попадает)
Route::prefix('admin')->name('admin.')->middleware(['auth', 'role:admin|manager'])->group(function () {

    Route::get('/', DashboardController::class)->name('dashboard');

    Route::resource('categories', ServiceCategoryController::class)->except(['show']);
    Route::resource('services', ServiceController::class)->except(['show']);
    Route::resource('masters', MasterController::class)->except(['show']);

    Route::resource('bookings', BookingController::class)->only(['index', 'edit', 'update', 'destroy']);
    Route::post('bookings/bulk', [BookingController::class, 'bulk'])->name('bookings.bulk');
    Route::get('bookings-calendar', [CalendarController::class, 'index'])->name('bookings.calendar');
    Route::get('bookings-calendar/events', [CalendarController::class, 'events'])->name('bookings.calendar.events');

    Route::get('reviews', [ReviewController::class, 'index'])->name('reviews.index');
    Route::patch('reviews/{review}/approve', [ReviewController::class, 'approve'])->name('reviews.approve');
    Route::patch('reviews/{review}/reject', [ReviewController::class, 'reject'])->name('reviews.reject');
    Route::delete('reviews/{review}', [ReviewController::class, 'destroy'])->name('reviews.destroy');

    Route::resource('gallery', GalleryItemController::class)->except(['show']);

    Route::get('messages', [ContactMessageController::class, 'index'])->name('messages.index');
    Route::get('messages/{message}', [ContactMessageController::class, 'show'])->name('messages.show');
    Route::delete('messages/{message}', [ContactMessageController::class, 'destroy'])->name('messages.destroy');

    // Пользователи, роли и настройки — только для admin (проверка дублируется в Policy)
    Route::middleware('role:admin')->group(function () {
        Route::resource('users', UserController::class)->except(['show']);
        Route::resource('roles', RoleController::class)->except(['show']);
        Route::get('settings', [SettingController::class, 'edit'])->name('settings.edit');
        Route::put('settings', [SettingController::class, 'update'])->name('settings.update');
    });
});
