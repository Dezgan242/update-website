<?php

use App\Http\Controllers\AboutController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\GalleryController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\ServiceController;
use Illuminate\Support\Facades\Route;

Route::get('/', HomeController::class)->name('home');

Route::get('/services', [ServiceController::class, 'index'])->name('services.index');
Route::get('/services/{service:slug}', [ServiceController::class, 'show'])->name('services.show');

Route::get('/about', AboutController::class)->name('about');

Route::get('/gallery', GalleryController::class)->name('gallery.index');

Route::get('/reviews', [ReviewController::class, 'index'])->name('reviews.index');
Route::post('/reviews', [ReviewController::class, 'store'])
    ->middleware(['honeypot', 'throttle:5,1'])
    ->name('reviews.store');

Route::get('/contacts', [ContactController::class, 'index'])->name('contacts.index');
Route::post('/contacts', [ContactController::class, 'store'])
    ->middleware(['honeypot', 'throttle:5,1'])
    ->name('contacts.store');

Route::get('/booking', [BookingController::class, 'create'])->name('booking.create');
Route::get('/booking/available-slots', [BookingController::class, 'availableSlots'])->name('booking.slots');
Route::post('/booking', [BookingController::class, 'store'])
    ->middleware(['honeypot', 'throttle:5,1'])
    ->name('booking.store');

// Личный кабинет клиента — только для авторизованных (регистрация/вход через Breeze)
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', DashboardController::class)->name('dashboard');

    Route::get('/profile', [App\Http\Controllers\ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [App\Http\Controllers\ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [App\Http\Controllers\ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
require __DIR__.'/admin.php';
