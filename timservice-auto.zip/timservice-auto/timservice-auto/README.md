# ТимСервис Авто — сайт автосервиса на Laravel 11

Публичный сайт (услуги, мастера, галерея до/после, отзывы, онлайн-запись, личный кабинет)
+ админ-панель (`/admin`) с ролями `admin` / `manager` / `client`.

## Важно: как устроена сборка

Этот код был подготовлен в среде **без доступа в интернет**, поэтому сюда включён
только прикладной код проекта (`app/`, `database/`, `resources/`, `routes/`,
конфиги сборки) — но не сам фреймворк Laravel (`vendor/`, `artisan`,
служебный `bootstrap/`), который скачивается через Composer. Поэтому запуск
состоит из двух этапов: сначала получить чистый скелет Laravel, затем
наложить поверх файлы из этого архива.

## Установка

### 1. Получить чистый скелет Laravel 11

```bash
composer create-project laravel/laravel timservice-auto "^11.0"
cd timservice-auto
```

### 2. Распаковать этот архив поверх

Распакуйте содержимое архива `timservice-auto.zip` в папку проекта,
**подтверждая замену** файлов `composer.json`, `package.json`, `.env.example`,
`bootstrap/app.php`, `routes/web.php`, `routes/console.php` — они полностью
заменяют дефолтные. Остальное (`app/`, `database/`, `resources/`) — новые файлы,
дополняющие проект.

> Аутентификация (логин/регистрация/сброс пароля) уже написана вручную по
> образцу Laravel Breeze (Blade-стек) — **не запускайте** `breeze:install`,
> это перезапишет наши файлы.

### 3. Установить зависимости

```bash
composer install
npm install
```

### 4. Настроить окружение

```bash
cp .env.example .env
php artisan key:generate
```

Создайте базу данных MySQL:

```sql
CREATE DATABASE timservice_auto CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

и укажите доступ в `.env` (`DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD`).

**Быстрый старт без MySQL:** в `.env` закомментируйте блок `DB_CONNECTION=mysql...`
и раскомментируйте блок SQLite, затем:

```bash
touch database/database.sqlite
```

### 5. Опубликовать конфиги пакетов (обязательно перед миграциями)

```bash
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
php artisan vendor:publish --provider="Spatie\MediaLibrary\MediaLibraryServiceProvider" --tag="medialibrary-config"
```

### 6. Миграции и демо-данные

```bash
php artisan migrate --seed
php artisan storage:link
```

### 7. Собрать фронтенд

```bash
npm run build
# или для разработки с горячей перезагрузкой:
npm run dev
```

### 8. Запустить

```bash
php artisan serve
```

Сайт — http://127.0.0.1:8000, админка — http://127.0.0.1:8000/admin

## Тестовые доступы (после `migrate --seed`)

| Роль | Email | Пароль |
|---|---|---|
| Администратор | `admin@timservice-auto.local` | `password` |
| Менеджер | `manager@timservice-auto.local` | `password` |
| Клиент (пример) | `client1@timservice-auto.local` | `password` |

Письма по умолчанию не отправляются реально — `MAIL_MAILER=log` в `.env`,
все письма попадают в `storage/logs/laravel.log`. Чтобы включить реальную
отправку, смените на `smtp` и укажите данные почтового сервера.

## Структура демо-данных

- 5 категорий услуг, 15 услуг
- 5 мастеров с привязкой к услугам по специализации
- 40 заявок (часть в прошлом со статусами «выполнена»/«отменена», часть
  предстоящих «новая»/«в работе»)
- 20 отзывов (16 опубликованы, 4 на модерации — проверьте раздел «Отзывы» в админке)
- 8 работ в галерее (без реальных фото — заглушки; загрузите фото через
  админку, drag&drop работает через стандартный `<input type="file">`)
- Настройки сайта (контакты, соцсети, SEO) с демо-значениями

## Чек-лист после установки

- [ ] `php artisan migrate:status` не выдаёт ошибок подключения к БД
- [ ] `php artisan vendor:publish` для Permission и MediaLibrary выполнен
      **до** `migrate` (иначе миграция ролей упадёт — ей нужен `config/permission.php`)
- [ ] `storage/app/public` доступен через `public/storage` (`storage:link`)
- [ ] Вход в `/admin` под `admin@timservice-auto.local` открывает дашборд
      с метриками и графиком
- [ ] Раздел «Отзывы» в админке показывает 4 отзыва на модерации
- [ ] Форма `/booking` подгружает свободное время по AJAX при выборе
      услуги и даты
- [ ] `npm run build` (или `dev`) собирает Tailwind без ошибок — стили
      должны быть в тёмно-синей/оранжевой гамме
- [ ] Письма при создании заявки появляются в `storage/logs/laravel.log`
      (при `MAIL_MAILER=log`)

## Известные упрощения (осознанный выбор, не баг)

- Изображения в сидерах не прикладываются (нет интернета в среде сборки
  этого проекта) — модели показывают включённые в архив SVG-заглушки
  (`public/images/*-placeholder.svg`), пока вы не загрузите реальные фото
  через админку.
- Sitemap.xml и robots.txt не сгенерированы файлами — при необходимости
  добавьте пакет `spatie/laravel-sitemap` или простой artisan-command,
  который пробежится по `Service`/`ServiceCategory`/`GalleryItem`.
- Календарь показывает только текущую и соседние недели через query-параметр
  `week`, без drag&drop переноса записи (только переход по ссылке на
  редактирование заявки).
