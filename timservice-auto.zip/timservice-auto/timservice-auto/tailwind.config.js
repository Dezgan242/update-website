import forms from '@tailwindcss/forms';
import typography from '@tailwindcss/typography';
import defaultTheme from 'tailwindcss/defaultTheme';

/** @type {import('tailwindcss').Config} */
export default {
    content: [
        './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
        './storage/framework/views/*.php',
        './resources/views/**/*.blade.php',
    ],
    theme: {
        extend: {
            fontFamily: {
                sans: ['Manrope', ...defaultTheme.fontFamily.sans],
            },
            colors: {
                // Тёмно-синяя/оранжевая автомотив-гамма
                navy: {
                    50: '#eef1f7',
                    100: '#d7ddec',
                    200: '#adbbd9',
                    300: '#8399c6',
                    400: '#5977b3',
                    500: '#3a5896',
                    600: '#2c4576',
                    700: '#1f3257',
                    800: '#141f38',
                    900: '#0a0f1c',
                },
                accent: {
                    50: '#fff4ed',
                    100: '#ffe6d5',
                    200: '#fecdaa',
                    300: '#fdad74',
                    400: '#fb8a3c',
                    500: '#f97316',
                    600: '#ea580c',
                    700: '#c2410c',
                    800: '#9a3412',
                    900: '#7c2d12',
                },
            },
        },
    },
    plugins: [forms, typography],
};
