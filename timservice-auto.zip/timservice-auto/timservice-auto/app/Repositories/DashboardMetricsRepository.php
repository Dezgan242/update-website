<?php

namespace App\Repositories;

use App\Enums\BookingStatus;
use App\Models\Booking;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

// Репозиторий вынесен отдельно, т.к. запросы дашборда — агрегирующие
// и не вписываются в обычные скоупы моделей.
class DashboardMetricsRepository
{
    public function bookingsCountToday(): int
    {
        return Booking::query()->whereDate('booking_date', now()->toDateString())->count();
    }

    public function bookingsCountThisWeek(): int
    {
        return Booking::query()
            ->whereBetween('booking_date', [now()->startOfWeek(), now()->endOfWeek()])
            ->count();
    }

    public function bookingsCountThisMonth(): int
    {
        return Booking::query()
            ->whereYear('booking_date', now()->year)
            ->whereMonth('booking_date', now()->month)
            ->count();
    }

    // Условная «выручка» — сумма price_from по выполненным заявкам за текущий месяц
    public function revenueThisMonth(): float
    {
        return (float) Booking::query()
            ->join('services', 'services.id', '=', 'bookings.service_id')
            ->where('bookings.status', BookingStatus::Completed->value)
            ->whereYear('bookings.booking_date', now()->year)
            ->whereMonth('bookings.booking_date', now()->month)
            ->sum('services.price_from');
    }

    public function topServices(int $limit = 5): Collection
    {
        return Booking::query()
            ->select('services.name', DB::raw('count(*) as bookings_count'))
            ->join('services', 'services.id', '=', 'bookings.service_id')
            ->groupBy('services.id', 'services.name')
            ->orderByDesc('bookings_count')
            ->limit($limit)
            ->get();
    }

    // Данные для графика заявок по дням за последние 14 дней
    public function bookingsByDayChart(int $days = 14): Collection
    {
        $from = now()->subDays($days - 1)->startOfDay();

        $raw = Booking::query()
            ->select(DB::raw('DATE(booking_date) as day'), DB::raw('count(*) as total'))
            ->where('booking_date', '>=', $from)
            ->groupBy('day')
            ->pluck('total', 'day');

        return collect(range(0, $days - 1))->map(function (int $offset) use ($from, $raw) {
            $day = $from->copy()->addDays($offset)->toDateString();

            return ['day' => $day, 'total' => (int) ($raw[$day] ?? 0)];
        });
    }

    public function bookingsByStatusCounts(): array
    {
        return Booking::query()
            ->select('status', DB::raw('count(*) as total'))
            ->groupBy('status')
            ->pluck('total', 'status')
            ->all();
    }
}
