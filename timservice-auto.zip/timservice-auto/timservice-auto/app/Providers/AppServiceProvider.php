<?php

namespace App\Providers;

use App\Models\Setting;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Контакты нужны в шапке и подвале на каждой публичной странице —
        // проще расшарить один раз тут, чем прокидывать через каждый контроллер.
        // Policy-классы регистрировать вручную не нужно: имена App\Policies\{Model}Policy
        // соответствуют конвенции автообнаружения Laravel.
        View::composer(['partials.header', 'partials.footer'], function ($view) {
            $view->with('globalContacts', Setting::group('contacts'));
            $view->with('globalSocials', Setting::group('social'));
        });
    }
}
