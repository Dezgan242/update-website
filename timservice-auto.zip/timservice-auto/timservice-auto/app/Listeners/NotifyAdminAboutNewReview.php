<?php

namespace App\Listeners;

use App\Events\ReviewSubmitted;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Log;

// Простое лог-уведомление админу о новом отзыве, ожидающем модерации
// (письмо не заводим отдельным Mailable, чтобы не плодить шаблоны ради одной строки)
class NotifyAdminAboutNewReview implements ShouldQueue
{
    public function handle(ReviewSubmitted $event): void
    {
        Log::info('Новый отзыв ожидает модерации', [
            'review_id' => $event->review->id,
            'name' => $event->review->name,
            'rating' => $event->review->rating,
        ]);
    }
}
