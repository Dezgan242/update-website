<?php

namespace App\Listeners;

use App\Events\BookingCreated;
use App\Mail\BookingCreatedAdminMail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Mail;

// Отправляет уведомление администратору о каждой новой заявке
class SendBookingNotificationToAdmin implements ShouldQueue
{
    public function handle(BookingCreated $event): void
    {
        $adminEmail = config('booking.admin_notification_email');

        if (! $adminEmail) {
            return;
        }

        Mail::to($adminEmail)->send(new BookingCreatedAdminMail($event->booking));
    }
}
