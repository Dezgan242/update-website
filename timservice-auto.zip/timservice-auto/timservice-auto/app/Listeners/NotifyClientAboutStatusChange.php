<?php

namespace App\Listeners;

use App\Events\BookingStatusChanged;
use App\Mail\BookingStatusChangedMail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Mail;

// Уведомляет клиента, когда менеджер сменил статус его заявки
class NotifyClientAboutStatusChange implements ShouldQueue
{
    public function handle(BookingStatusChanged $event): void
    {
        if (! $event->booking->email) {
            return;
        }

        Mail::to($event->booking->email)->send(new BookingStatusChangedMail($event->booking));
    }
}
