<?php

namespace App\Listeners;

use App\Events\BookingCreated;
use App\Mail\BookingCreatedClientMail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Mail;

// Отправляет клиенту письмо-подтверждение, если он указал email
class SendBookingConfirmationToClient implements ShouldQueue
{
    public function handle(BookingCreated $event): void
    {
        if (! $event->booking->email) {
            return;
        }

        Mail::to($event->booking->email)->send(new BookingCreatedClientMail($event->booking));
    }
}
