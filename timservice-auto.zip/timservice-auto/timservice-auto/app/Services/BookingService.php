<?php

namespace App\Services;

use App\Enums\BookingStatus;
use App\Events\BookingCreated;
use App\Events\BookingStatusChanged;
use App\Models\Booking;
use App\Models\Service;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class BookingService
{
    /**
     * Создать заявку на запись с проверкой занятости слота мастера.
     * Проверка + вставка выполняются в транзакции с блокировкой строк,
     * чтобы исключить гонку запросов при одновременной записи на один слот.
     */
    public function createBooking(array $data): Booking
    {
        return DB::transaction(function () use ($data) {
            if (! empty($data['master_id'])) {
                $this->assertSlotIsFree(
                    masterId: $data['master_id'],
                    date: $data['booking_date'],
                    time: $data['booking_time'],
                );
            }

            $booking = Booking::create([
                'user_id' => $data['user_id'] ?? null,
                'name' => $data['name'],
                'phone' => $data['phone'],
                'email' => $data['email'] ?? null,
                'car_brand' => $data['car_brand'] ?? null,
                'car_model' => $data['car_model'] ?? null,
                'service_id' => $data['service_id'],
                'master_id' => $data['master_id'] ?? null,
                'booking_date' => $data['booking_date'],
                'booking_time' => $data['booking_time'],
                'comment' => $data['comment'] ?? null,
                'status' => BookingStatus::New,
                'source' => $data['source'] ?? 'website',
                'consent_pd' => $data['consent_pd'] ?? true,
            ]);

            event(new BookingCreated($booking));

            return $booking;
        });
    }

    /**
     * Сменить статус заявки, назначить мастера, сохранить заметку менеджера.
     */
    public function updateBooking(Booking $booking, array $data): Booking
    {
        return DB::transaction(function () use ($booking, $data) {
            $previousStatus = $booking->status;

            if (! empty($data['master_id']) && (
                $data['master_id'] != $booking->master_id
                || $data['booking_date'] != $booking->booking_date->toDateString()
                || $data['booking_time'] != substr($booking->booking_time, 0, 5)
            )) {
                $this->assertSlotIsFree(
                    masterId: $data['master_id'],
                    date: $data['booking_date'],
                    time: $data['booking_time'],
                    excludeBookingId: $booking->id,
                );
            }

            $booking->update([
                'status' => $data['status'],
                'master_id' => $data['master_id'] ?? null,
                'booking_date' => $data['booking_date'],
                'booking_time' => $data['booking_time'],
                'admin_notes' => $data['admin_notes'] ?? $booking->admin_notes,
            ]);

            if ($previousStatus->value !== $booking->status->value) {
                event(new BookingStatusChanged($booking, $previousStatus));
            }

            return $booking->fresh();
        });
    }

    /**
     * Получить свободные интервалы времени на дату для выбранной услуги/мастера.
     * Рабочий день — с 09:00 до 19:00, шаг — длительность услуги.
     */
    public function availableSlots(Service $service, string $date, ?int $masterId = null): array
    {
        $slotMinutes = max(30, $service->duration_minutes);
        $start = \Carbon\Carbon::parse($date)->setTime(9, 0);
        $end = \Carbon\Carbon::parse($date)->setTime(19, 0);

        $busyTimes = Booking::query()
            ->when($masterId, fn ($q) => $q->where('master_id', $masterId))
            ->forDate($date)
            ->whereNotIn('status', [BookingStatus::Cancelled->value])
            ->pluck('booking_time')
            ->map(fn ($time) => substr($time, 0, 5))
            ->all();

        $slots = [];
        $cursor = $start->copy();

        while ($cursor->lt($end)) {
            $slotLabel = $cursor->format('H:i');
            if (! in_array($slotLabel, $busyTimes, true)) {
                $slots[] = $slotLabel;
            }
            $cursor->addMinutes($slotMinutes);
        }

        return $slots;
    }

    protected function assertSlotIsFree(int $masterId, string $date, string $time, ?int $excludeBookingId = null): void
    {
        $exists = Booking::query()
            ->where('master_id', $masterId)
            ->whereDate('booking_date', $date)
            ->whereTime('booking_time', $time)
            ->whereNotIn('status', [BookingStatus::Cancelled->value])
            ->when($excludeBookingId, fn ($q) => $q->where('id', '!=', $excludeBookingId))
            ->lockForUpdate()
            ->exists();

        if ($exists) {
            throw ValidationException::withMessages([
                'booking_time' => 'Это время уже занято, выберите другой слот.',
            ]);
        }
    }
}
