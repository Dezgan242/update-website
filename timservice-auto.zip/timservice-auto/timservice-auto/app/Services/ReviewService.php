<?php

namespace App\Services;

use App\Events\ReviewSubmitted;
use App\Models\Review;

class ReviewService
{
    /**
     * Создать отзыв. Все новые отзывы уходят на модерацию (is_approved = false)
     * независимо от того, что пришло в запросе — решение принимает только админ/менеджер.
     */
    public function submitReview(array $data): Review
    {
        $review = Review::create([
            'user_id' => $data['user_id'] ?? null,
            'service_id' => $data['service_id'] ?? null,
            'name' => $data['name'],
            'phone' => $data['phone'] ?? null,
            'email' => $data['email'] ?? null,
            'rating' => $data['rating'],
            'text' => $data['text'],
            'is_approved' => false,
            'consent_pd' => $data['consent_pd'] ?? true,
        ]);

        event(new ReviewSubmitted($review));

        return $review;
    }

    public function approve(Review $review): Review
    {
        $review->update(['is_approved' => true]);

        return $review;
    }

    public function reject(Review $review): Review
    {
        $review->update(['is_approved' => false]);

        return $review;
    }
}
