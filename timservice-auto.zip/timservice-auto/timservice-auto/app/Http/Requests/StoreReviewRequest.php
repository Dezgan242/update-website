<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

// Валидация публичной формы отправки отзыва (без регистрации)
class StoreReviewRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'phone' => ['nullable', 'string', 'max:20'],
            'email' => ['nullable', 'email', 'max:255'],
            'service_id' => ['nullable', 'integer', Rule::exists('services', 'id')],
            'rating' => ['required', 'integer', 'min:1', 'max:5'],
            'text' => ['required', 'string', 'min:10', 'max:2000'],
            'consent_pd' => ['accepted'],
            'website' => ['prohibited'],
        ];
    }

    public function messages(): array
    {
        return [
            'text.min' => 'Отзыв слишком короткий, напишите чуть подробнее.',
            'rating.required' => 'Поставьте оценку от 1 до 5.',
            'consent_pd.accepted' => 'Необходимо согласие на обработку персональных данных.',
        ];
    }
}
