<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

// Валидация формы обратной связи на странице контактов
class StoreContactMessageRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['nullable', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:20'],
            'message' => ['required', 'string', 'min:5', 'max:2000'],
            'consent_pd' => ['accepted'],
            'website' => ['prohibited'],
        ];
    }

    public function messages(): array
    {
        return [
            'message.required' => 'Напишите, пожалуйста, сообщение.',
            'consent_pd.accepted' => 'Необходимо согласие на обработку персональных данных.',
        ];
    }
}
