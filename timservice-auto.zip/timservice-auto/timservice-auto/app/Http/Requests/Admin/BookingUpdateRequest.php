<?php

namespace App\Http\Requests\Admin;

use App\Enums\BookingStatus;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

// Обновление заявки менеджером: статус, назначенный мастер, заметки
class BookingUpdateRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'status' => ['required', Rule::in(BookingStatus::values())],
            'master_id' => ['nullable', 'integer', Rule::exists('masters', 'id')],
            'booking_date' => ['required', 'date'],
            'booking_time' => ['required', 'date_format:H:i'],
            'admin_notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
