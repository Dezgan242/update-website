<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

// Валидация публичной формы онлайн-записи (доступна и гостям, и авторизованным)
class StoreBookingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'phone' => ['required', 'string', 'max:20', 'regex:/^[0-9+\-\s\(\)]{6,20}$/'],
            'email' => ['nullable', 'email', 'max:255'],
            'car_brand' => ['nullable', 'string', 'max:100'],
            'car_model' => ['nullable', 'string', 'max:100'],
            'service_id' => ['required', 'integer', Rule::exists('services', 'id')->where('is_active', true)],
            'master_id' => ['nullable', 'integer', Rule::exists('masters', 'id')->where('is_active', true)],
            'booking_date' => ['required', 'date', 'after_or_equal:today'],
            'booking_time' => ['required', 'date_format:H:i'],
            'comment' => ['nullable', 'string', 'max:1000'],
            'consent_pd' => ['accepted'], // согласие на обработку персональных данных, 152-ФЗ
            // honeypot-поле: обычный пользователь его не видит и не заполняет
            'website' => ['prohibited'],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Укажите, пожалуйста, имя.',
            'phone.required' => 'Укажите номер телефона.',
            'phone.regex' => 'Проверьте формат номера телефона.',
            'service_id.required' => 'Выберите услугу.',
            'booking_date.after_or_equal' => 'Дата записи не может быть в прошлом.',
            'consent_pd.accepted' => 'Необходимо согласие на обработку персональных данных.',
        ];
    }
}
