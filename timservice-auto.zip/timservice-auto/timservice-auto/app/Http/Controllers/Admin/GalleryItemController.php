<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\GalleryItemRequest;
use App\Models\GalleryItem;
use App\Models\ServiceCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class GalleryItemController extends Controller
{
    public function index(): View
    {
        $this->authorize('viewAny', GalleryItem::class);

        $items = GalleryItem::query()->with('category')->ordered()->paginate(12);

        return view('admin.gallery.index', compact('items'));
    }

    public function create(): View
    {
        $this->authorize('create', GalleryItem::class);

        return view('admin.gallery.form', [
            'item' => new GalleryItem(),
            'categories' => ServiceCategory::query()->ordered()->get(),
        ]);
    }

    public function store(GalleryItemRequest $request): RedirectResponse
    {
        $this->authorize('create', GalleryItem::class);

        $data = $request->validated();
        $item = GalleryItem::create(collect($data)->except(['before_image', 'after_image'])->all());

        if ($request->hasFile('before_image')) {
            $item->addMediaFromRequest('before_image')->toMediaCollection('before');
        }
        if ($request->hasFile('after_image')) {
            $item->addMediaFromRequest('after_image')->toMediaCollection('after');
        }

        return redirect()->route('admin.gallery.index')->with('success', 'Работа добавлена в галерею.');
    }

    public function edit(GalleryItem $item): View
    {
        $this->authorize('update', $item);

        return view('admin.gallery.form', [
            'item' => $item,
            'categories' => ServiceCategory::query()->ordered()->get(),
        ]);
    }

    public function update(GalleryItemRequest $request, GalleryItem $item): RedirectResponse
    {
        $this->authorize('update', $item);

        $data = $request->validated();
        $item->update(collect($data)->except(['before_image', 'after_image'])->all());

        if ($request->hasFile('before_image')) {
            $item->addMediaFromRequest('before_image')->toMediaCollection('before');
        }
        if ($request->hasFile('after_image')) {
            $item->addMediaFromRequest('after_image')->toMediaCollection('after');
        }

        return redirect()->route('admin.gallery.index')->with('success', 'Работа обновлена.');
    }

    public function destroy(GalleryItem $item): RedirectResponse
    {
        $this->authorize('delete', $item);

        $item->delete();

        return back()->with('success', 'Работа удалена из галереи.');
    }
}
