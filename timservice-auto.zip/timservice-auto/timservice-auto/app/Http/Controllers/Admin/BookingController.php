<?php

namespace App\Http\Controllers\Admin;

use App\Enums\BookingStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\BookingUpdateRequest;
use App\Models\Booking;
use App\Models\Master;
use App\Models\Service;
use App\Services\BookingService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class BookingController extends Controller
{
    public function __construct(protected BookingService $bookingService)
    {
    }

    // Список заявок с фильтрами по дате/статусу/услуге и поиском по имени/телефону.
    // Пагинация сохраняет query-параметры через withQueryString().
    public function index(Request $request): View
    {
        $this->authorize('viewAny', Booking::class);

        $bookings = Booking::query()
            ->with(['service', 'master', 'user'])
            ->when($request->filled('status'), fn ($q) => $q->status($request->string('status')->toString()))
            ->when($request->filled('service_id'), fn ($q) => $q->where('service_id', $request->integer('service_id')))
            ->when($request->filled('date_from'), fn ($q) => $q->whereDate('booking_date', '>=', $request->date('date_from')))
            ->when($request->filled('date_to'), fn ($q) => $q->whereDate('booking_date', '<=', $request->date('date_to')))
            ->when($request->filled('search'), function ($q) use ($request) {
                $search = $request->string('search')->toString();
                $q->where(fn ($sub) => $sub->where('name', 'like', "%{$search}%")->orWhere('phone', 'like', "%{$search}%"));
            })
            ->latest('booking_date')
            ->paginate(20)
            ->withQueryString();

        $services = Service::query()->orderBy('name')->get();

        return view('admin.bookings.index', [
            'bookings' => $bookings,
            'services' => $services,
            'statuses' => BookingStatus::options(),
        ]);
    }

    public function edit(Booking $booking): View
    {
        $this->authorize('update', $booking);

        $masters = Master::query()->active()->ordered()->get();

        return view('admin.bookings.edit', [
            'booking' => $booking,
            'masters' => $masters,
            'statuses' => BookingStatus::options(),
        ]);
    }

    public function update(BookingUpdateRequest $request, Booking $booking): RedirectResponse
    {
        $this->authorize('update', $booking);

        $this->bookingService->updateBooking($booking, $request->validated());

        return redirect()->route('admin.bookings.index')->with('success', 'Заявка обновлена.');
    }

    public function destroy(Booking $booking): RedirectResponse
    {
        $this->authorize('delete', $booking);

        $booking->delete();

        return back()->with('success', 'Заявка удалена.');
    }

    // Массовые действия: удаление или смена статуса выбранных заявок разом
    public function bulk(Request $request): RedirectResponse
    {
        $this->authorize('viewAny', Booking::class);

        $data = $request->validate([
            'ids' => ['required', 'array'],
            'ids.*' => ['integer', 'exists:bookings,id'],
            'action' => ['required', 'in:delete,set_status'],
            'status' => ['required_if:action,set_status', 'nullable', 'in:'.implode(',', BookingStatus::values())],
        ]);

        $query = Booking::query()->whereIn('id', $data['ids']);

        if ($data['action'] === 'delete') {
            $this->authorize('delete', new Booking());
            $query->delete();

            return back()->with('success', 'Выбранные заявки удалены.');
        }

        $query->update(['status' => $data['status']]);

        return back()->with('success', 'Статус выбранных заявок обновлён.');
    }
}
