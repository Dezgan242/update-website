<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\SettingRequest;
use App\Models\Setting;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class SettingController extends Controller
{
    // Карта полей -> группа настроек, чтобы не размазывать эту логику по контроллеру
    private const FIELD_GROUPS = [
        'contact_phone' => 'contacts',
        'contact_email' => 'contacts',
        'contact_address' => 'contacts',
        'work_hours' => 'contacts',
        'map_iframe' => 'contacts',
        'social_vk' => 'social',
        'social_telegram' => 'social',
        'social_whatsapp' => 'social',
        'seo_title' => 'seo',
        'seo_description' => 'seo',
    ];

    public function edit(): View
    {
        $settings = Setting::query()->pluck('value', 'key');

        return view('admin.settings.edit', compact('settings'));
    }

    public function update(SettingRequest $request): RedirectResponse
    {
        foreach ($request->validated() as $key => $value) {
            Setting::set($key, $value, self::FIELD_GROUPS[$key] ?? 'general');
        }

        return back()->with('success', 'Настройки сохранены.');
    }
}
