<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Review;
use App\Services\ReviewService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ReviewController extends Controller
{
    public function __construct(protected ReviewService $reviewService)
    {
    }

    public function index(Request $request): View
    {
        $this->authorize('viewAny', Review::class);

        $reviews = Review::query()
            ->with(['service', 'user'])
            ->when($request->filled('status'), function ($q) use ($request) {
                $q->where('is_approved', $request->string('status') === 'approved');
            })
            ->latest()
            ->paginate(15)
            ->withQueryString();

        return view('admin.reviews.index', compact('reviews'));
    }

    public function approve(Review $review): RedirectResponse
    {
        $this->authorize('update', $review);

        $this->reviewService->approve($review);

        return back()->with('success', 'Отзыв опубликован.');
    }

    public function reject(Review $review): RedirectResponse
    {
        $this->authorize('update', $review);

        $this->reviewService->reject($review);

        return back()->with('success', 'Отзыв скрыт с сайта.');
    }

    public function destroy(Review $review): RedirectResponse
    {
        $this->authorize('delete', $review);

        $review->delete();

        return back()->with('success', 'Отзыв удалён.');
    }
}
