<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\RoleRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleController extends Controller
{
    public function index(): View
    {
        $this->authorize('viewAny', \App\Models\User::class);

        $roles = Role::query()->withCount('permissions', 'users')->orderBy('name')->get();

        return view('admin.roles.index', compact('roles'));
    }

    public function create(): View
    {
        $this->authorize('create', \App\Models\User::class);

        return view('admin.roles.form', [
            'role' => new Role(),
            'permissions' => Permission::query()->orderBy('name')->get(),
        ]);
    }

    public function store(RoleRequest $request): RedirectResponse
    {
        $this->authorize('create', \App\Models\User::class);

        $data = $request->validated();
        $role = Role::create(['name' => $data['name'], 'guard_name' => 'web']);
        $role->syncPermissions($data['permissions'] ?? []);

        return redirect()->route('admin.roles.index')->with('success', 'Роль создана.');
    }

    public function edit(Role $role): View
    {
        $this->authorize('update', \App\Models\User::class);

        return view('admin.roles.form', [
            'role' => $role,
            'permissions' => Permission::query()->orderBy('name')->get(),
        ]);
    }

    public function update(RoleRequest $request, Role $role): RedirectResponse
    {
        $this->authorize('update', \App\Models\User::class);

        $data = $request->validated();
        $role->update(['name' => $data['name']]);
        $role->syncPermissions($data['permissions'] ?? []);

        return redirect()->route('admin.roles.index')->with('success', 'Роль обновлена.');
    }

    public function destroy(Role $role): RedirectResponse
    {
        $this->authorize('delete', \App\Models\User::class);

        abort_if(in_array($role->name, ['admin', 'manager', 'client']), 403, 'Базовые роли системы удалить нельзя.');

        $role->delete();

        return back()->with('success', 'Роль удалена.');
    }
}
