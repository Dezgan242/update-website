<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ServiceRequest;
use App\Models\Master;
use App\Models\Service;
use App\Models\ServiceCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ServiceController extends Controller
{
    public function index(Request $request): View
    {
        $this->authorize('viewAny', Service::class);

        $services = Service::query()
            ->with('category')
            ->when($request->filled('search'), fn ($q) => $q->where('name', 'like', '%'.$request->string('search').'%'))
            ->when($request->filled('category_id'), fn ($q) => $q->where('category_id', $request->integer('category_id')))
            ->orderBy('sort_order')
            ->paginate(15)
            ->withQueryString();

        $categories = ServiceCategory::query()->ordered()->get();

        return view('admin.services.index', compact('services', 'categories'));
    }

    public function create(): View
    {
        $this->authorize('create', Service::class);

        return view('admin.services.form', [
            'service' => new Service(),
            'categories' => ServiceCategory::query()->ordered()->get(),
            'masters' => Master::query()->ordered()->get(),
        ]);
    }

    public function store(ServiceRequest $request): RedirectResponse
    {
        $this->authorize('create', Service::class);

        $data = $request->validated();
        $service = Service::create(collect($data)->except(['cover', 'master_ids'])->all());

        if ($request->hasFile('cover')) {
            $service->addMediaFromRequest('cover')->toMediaCollection('cover');
        }

        $service->masters()->sync($data['master_ids'] ?? []);

        return redirect()->route('admin.services.index')->with('success', 'Услуга создана.');
    }

    public function edit(Service $service): View
    {
        $this->authorize('update', $service);

        $service->load('masters');

        return view('admin.services.form', [
            'service' => $service,
            'categories' => ServiceCategory::query()->ordered()->get(),
            'masters' => Master::query()->ordered()->get(),
        ]);
    }

    public function update(ServiceRequest $request, Service $service): RedirectResponse
    {
        $this->authorize('update', $service);

        $data = $request->validated();
        $service->update(collect($data)->except(['cover', 'master_ids'])->all());

        if ($request->hasFile('cover')) {
            $service->addMediaFromRequest('cover')->toMediaCollection('cover');
        }

        $service->masters()->sync($data['master_ids'] ?? []);

        return redirect()->route('admin.services.index')->with('success', 'Услуга обновлена.');
    }

    public function destroy(Service $service): RedirectResponse
    {
        $this->authorize('delete', $service);

        $service->delete();

        return back()->with('success', 'Услуга удалена.');
    }
}
