<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Repositories\DashboardMetricsRepository;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __construct(protected DashboardMetricsRepository $metrics)
    {
    }

    public function index(): View
    {
        return view('admin.dashboard', [
            'bookingsToday' => $this->metrics->bookingsCountToday(),
            'bookingsThisWeek' => $this->metrics->bookingsCountThisWeek(),
            'bookingsThisMonth' => $this->metrics->bookingsCountThisMonth(),
            'revenueThisMonth' => $this->metrics->revenueThisMonth(),
            'topServices' => $this->metrics->topServices(),
            'chartData' => $this->metrics->bookingsByDayChart(),
            'statusCounts' => $this->metrics->bookingsByStatusCounts(),
        ]);
    }
}
