<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Master;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CalendarController extends Controller
{
    // Отдаёт HTML-страницу с недельной сеткой, данные подгружаются через events() по AJAX
    public function index(Request $request): View
    {
        $this->authorize('viewAny', Booking::class);

        $weekStart = $request->filled('week')
            ? Carbon::parse($request->string('week')->toString())->startOfWeek()
            : now()->startOfWeek();

        $masters = Master::query()->active()->ordered()->get();

        return view('admin.bookings.calendar', [
            'weekStart' => $weekStart,
            'masters' => $masters,
        ]);
    }

    // JSON-эндпоинт с заявками недели для рендера в календаре через Alpine.js
    public function events(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Booking::class);

        $weekStart = Carbon::parse($request->string('week')->toString() ?: now())->startOfWeek();
        $weekEnd = $weekStart->copy()->endOfWeek();

        $bookings = Booking::query()
            ->with(['service', 'master'])
            ->whereBetween('booking_date', [$weekStart->toDateString(), $weekEnd->toDateString()])
            ->get()
            ->map(fn (Booking $b) => [
                'id' => $b->id,
                'title' => $b->name.' — '.$b->service->name,
                'date' => $b->booking_date->toDateString(),
                'time' => substr($b->booking_time, 0, 5),
                'master' => $b->master?->name,
                'status' => $b->status->value,
                'status_label' => $b->status->label(),
                'edit_url' => route('admin.bookings.edit', $b),
            ]);

        return response()->json(['events' => $bookings]);
    }
}
