<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\MasterRequest;
use App\Models\Master;
use App\Models\Service;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class MasterController extends Controller
{
    public function index(Request $request): View
    {
        $this->authorize('viewAny', Master::class);

        $masters = Master::query()
            ->when($request->filled('search'), fn ($q) => $q->where('name', 'like', '%'.$request->string('search').'%'))
            ->ordered()
            ->paginate(15)
            ->withQueryString();

        return view('admin.masters.index', compact('masters'));
    }

    public function create(): View
    {
        $this->authorize('create', Master::class);

        return view('admin.masters.form', [
            'master' => new Master(),
            'services' => Service::query()->active()->orderBy('name')->get(),
        ]);
    }

    public function store(MasterRequest $request): RedirectResponse
    {
        $this->authorize('create', Master::class);

        $data = $request->validated();
        $master = Master::create(collect($data)->except(['photo', 'service_ids'])->all());

        if ($request->hasFile('photo')) {
            $master->addMediaFromRequest('photo')->toMediaCollection('photo');
        }

        $master->services()->sync($data['service_ids'] ?? []);

        return redirect()->route('admin.masters.index')->with('success', 'Мастер добавлен.');
    }

    public function edit(Master $master): View
    {
        $this->authorize('update', $master);

        $master->load('services');

        return view('admin.masters.form', [
            'master' => $master,
            'services' => Service::query()->active()->orderBy('name')->get(),
        ]);
    }

    public function update(MasterRequest $request, Master $master): RedirectResponse
    {
        $this->authorize('update', $master);

        $data = $request->validated();
        $master->update(collect($data)->except(['photo', 'service_ids'])->all());

        if ($request->hasFile('photo')) {
            $master->addMediaFromRequest('photo')->toMediaCollection('photo');
        }

        $master->services()->sync($data['service_ids'] ?? []);

        return redirect()->route('admin.masters.index')->with('success', 'Данные мастера обновлены.');
    }

    public function destroy(Master $master): RedirectResponse
    {
        $this->authorize('delete', $master);

        $master->delete();

        return back()->with('success', 'Мастер удалён.');
    }
}
