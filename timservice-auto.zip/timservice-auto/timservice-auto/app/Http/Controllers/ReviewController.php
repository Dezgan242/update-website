<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreReviewRequest;
use App\Models\Review;
use App\Models\Service;
use App\Services\ReviewService;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class ReviewController extends Controller
{
    public function __construct(protected ReviewService $reviewService)
    {
    }

    public function index(): View
    {
        $reviews = Review::query()->approved()->latest()->paginate(10);
        $services = Service::query()->active()->orderBy('name')->get();

        return view('reviews.index', compact('reviews', 'services'));
    }

    // Rate limit применяется через middleware 'throttle:5,1' в routes/web.php
    public function store(StoreReviewRequest $request): RedirectResponse
    {
        $data = $request->validated();
        $data['user_id'] = $request->user()?->id;

        $this->reviewService->submitReview($data);

        return back()->with('success', 'Спасибо! Ваш отзыв отправлен и появится на сайте после проверки модератором.');
    }
}
