<?php

namespace App\Http\Controllers;

use App\Models\GalleryItem;
use App\Models\ServiceCategory;
use Illuminate\Http\Request;
use Illuminate\View\View;

class GalleryController extends Controller
{
    public function index(Request $request): View
    {
        $categories = ServiceCategory::query()->active()->ordered()->get();

        $items = GalleryItem::query()
            ->published()
            ->ordered()
            ->when($request->filled('category'), fn ($q) => $q->whereHas(
                'category',
                fn ($cq) => $cq->where('slug', $request->string('category'))
            ))
            ->paginate(9)
            ->withQueryString();

        return view('gallery.index', compact('items', 'categories'));
    }
}
