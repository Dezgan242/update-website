<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreContactMessageRequest;
use App\Models\ContactMessage;
use App\Models\Setting;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class ContactController extends Controller
{
    public function index(): View
    {
        $contacts = Setting::group('contacts');
        $socials = Setting::group('social');

        return view('contacts', compact('contacts', 'socials'));
    }

    public function store(StoreContactMessageRequest $request): RedirectResponse
    {
        ContactMessage::create($request->safe()->except(['consent_pd', 'website']));

        return back()->with('success', 'Сообщение отправлено! Мы свяжемся с вами в ближайшее время.');
    }
}
