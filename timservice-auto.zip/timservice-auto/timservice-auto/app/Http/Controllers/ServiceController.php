<?php

namespace App\Http\Controllers;

use App\Models\Service;
use App\Models\ServiceCategory;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ServiceController extends Controller
{
    // Каталог услуг с фильтром по категории
    public function index(Request $request): View
    {
        $categories = ServiceCategory::query()->active()->ordered()->with(['services' => function ($q) {
            $q->active()->orderBy('sort_order');
        }])->get();

        $selectedCategory = $request->string('category')->toString();

        return view('services.index', compact('categories', 'selectedCategory'));
    }

    // Карточка услуги (route model binding по slug)
    public function show(Service $service): View
    {
        abort_unless($service->is_active, 404);

        $service->load(['category', 'masters' => fn ($q) => $q->active()]);

        $reviews = $service->reviews()->approved()->latest()->limit(10)->get();

        $relatedServices = Service::query()
            ->active()
            ->where('category_id', $service->category_id)
            ->where('id', '!=', $service->id)
            ->limit(4)
            ->get();

        return view('services.show', compact('service', 'reviews', 'relatedServices'));
    }
}
