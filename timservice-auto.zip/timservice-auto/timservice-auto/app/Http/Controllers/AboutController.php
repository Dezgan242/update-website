<?php

namespace App\Http\Controllers;

use App\Models\Master;
use Illuminate\View\View;

class AboutController extends Controller
{
    // История компании (статичный текст во view) + команда мастеров из БД
    public function index(): View
    {
        $masters = Master::query()->active()->ordered()->with('services')->get();

        return view('about', compact('masters'));
    }
}
