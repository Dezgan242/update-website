<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\View\View;

class DashboardController extends Controller
{
    // Личный кабинет клиента: список его заявок со статусами
    public function index(Request $request): View
    {
        $bookings = $request->user()
            ->bookings()
            ->with(['service', 'master'])
            ->latest('booking_date')
            ->paginate(10);

        return view('dashboard.index', compact('bookings'));
    }
}
