<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreBookingRequest;
use App\Models\Master;
use App\Models\Service;
use App\Models\ServiceCategory;
use App\Services\BookingService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class BookingController extends Controller
{
    public function __construct(protected BookingService $bookingService)
    {
    }

    // Форма записи. Каскад категория -> услуга -> мастер реализован на Alpine.js во view,
    // тут отдаём только исходные данные для селектов.
    public function create(Request $request): View
    {
        $categories = ServiceCategory::query()->active()->ordered()->with(['services' => fn ($q) => $q->active()])->get();
        $masters = Master::query()->active()->ordered()->with('services')->get();

        $preselectedService = null;
        if ($request->filled('service')) {
            $preselectedService = Service::query()->active()->where('slug', $request->string('service'))->first();
        }

        return view('booking.create', compact('categories', 'masters', 'preselectedService'));
    }

    // AJAX: список свободных слотов на дату для услуги (и опционально мастера)
    public function availableSlots(Request $request): JsonResponse
    {
        $request->validate([
            'service_id' => ['required', 'integer', 'exists:services,id'],
            'master_id' => ['nullable', 'integer', 'exists:masters,id'],
            'date' => ['required', 'date', 'after_or_equal:today'],
        ]);

        $service = Service::findOrFail($request->integer('service_id'));

        $slots = $this->bookingService->availableSlots(
            service: $service,
            date: $request->string('date')->toString(),
            masterId: $request->integer('master_id') ?: null,
        );

        return response()->json(['slots' => $slots]);
    }

    // Rate limit применяется через middleware 'throttle:5,1' в routes/web.php
    public function store(StoreBookingRequest $request): RedirectResponse
    {
        $data = $request->validated();
        $data['user_id'] = $request->user()?->id;
        $data['source'] = 'website';

        $booking = $this->bookingService->createBooking($data);

        return redirect()
            ->route('booking.create')
            ->with('success', "Заявка №{$booking->id} принята! Мы свяжемся с вами для подтверждения.");
    }
}
