<?php

namespace App\Http\Controllers;

use App\Models\Master;
use App\Models\Review;
use App\Models\Service;
use App\Models\ServiceCategory;
use Illuminate\View\View;

class HomeController extends Controller
{
    // Главная: hero, преимущества, топ-услуги, мастера, отзывы, форма записи
    public function index(): View
    {
        $popularServices = Service::query()
            ->active()
            ->popular()
            ->with('category')
            ->orderBy('sort_order')
            ->limit(6)
            ->get();

        $categories = ServiceCategory::query()->active()->ordered()->get();

        $masters = Master::query()->active()->ordered()->limit(4)->get();

        $reviews = Review::query()
            ->approved()
            ->latest()
            ->limit(6)
            ->get();

        return view('home', compact('popularServices', 'categories', 'masters', 'reviews'));
    }
}
