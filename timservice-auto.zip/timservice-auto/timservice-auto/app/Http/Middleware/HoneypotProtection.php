<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

// Отбрасывает запрос, если скрытое honeypot-поле "website" заполнено (значит, это бот).
// Реальные пользователи это поле не видят (скрыто CSS) и не заполняют.
// Дополнительно к этому в Form Request уже есть правило 'website' => 'prohibited' —
// middleware даёт более раннее и лёгкое отсечение бота до валидации.
class HoneypotProtection
{
    public function handle(Request $request, Closure $next): Response
    {
        if ($request->filled('website')) {
            abort(422, 'Обнаружена подозрительная активность.');
        }

        return $next($request);
    }
}
