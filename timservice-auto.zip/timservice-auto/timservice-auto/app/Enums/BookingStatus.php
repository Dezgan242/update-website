<?php

namespace App\Enums;

// Статусы заявки на онлайн-запись. Строковый enum — значение хранится в поле bookings.status
enum BookingStatus: string
{
    case New = 'new';
    case InProgress = 'in_progress';
    case Completed = 'completed';
    case Cancelled = 'cancelled';

    // Человекочитаемая подпись для админки и писем
    public function label(): string
    {
        return match ($this) {
            self::New => 'Новая',
            self::InProgress => 'В работе',
            self::Completed => 'Выполнена',
            self::Cancelled => 'Отменена',
        };
    }

    // Цвет бейджа в админке (классы Tailwind)
    public function badgeClasses(): string
    {
        return match ($this) {
            self::New => 'bg-blue-100 text-blue-700',
            self::InProgress => 'bg-orange-100 text-orange-700',
            self::Completed => 'bg-green-100 text-green-700',
            self::Cancelled => 'bg-gray-200 text-gray-600',
        };
    }

    // Список значений для селектов и валидации Form Request
    public static function values(): array
    {
        return array_map(fn (self $case) => $case->value, self::cases());
    }

    // Опции вида ['value' => 'label'] для <select> в Blade
    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn (self $case) => [$case->value => $case->label()])
            ->all();
    }
}
