<?php

namespace App\Mail;

use App\Models\Booking;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

// Письмо клиенту при смене статуса его заявки (например, «в работе» -> «выполнена»)
class BookingStatusChangedMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public Booking $booking)
    {
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Статус вашей заявки изменён — '.config('app.name'),
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.booking-status-changed',
            with: ['booking' => $this->booking],
        );
    }
}
