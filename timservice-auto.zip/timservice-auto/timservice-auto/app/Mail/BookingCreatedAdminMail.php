<?php

namespace App\Mail;

use App\Models\Booking;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

// Письмо администратору о новой заявке
class BookingCreatedAdminMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public Booking $booking)
    {
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Новая заявка на запись №'.$this->booking->id,
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.booking-created-admin',
            with: ['booking' => $this->booking],
        );
    }
}
