<?php

namespace App\Policies;

use App\Models\Booking;
use App\Models\User;

class BookingPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['admin', 'manager']) || $user->hasRole('client');
    }

    // Клиент видит только свои заявки, admin/manager — любые (проверка владения — в контроллере/скоупе)
    public function view(User $user, Booking $booking): bool
    {
        if ($user->hasAnyRole(['admin', 'manager'])) {
            return true;
        }

        return $booking->user_id === $user->id;
    }

    public function update(User $user, Booking $booking): bool
    {
        return $user->hasAnyRole(['admin', 'manager']);
    }

    public function delete(User $user, Booking $booking): bool
    {
        return $user->hasRole('admin');
    }
}
