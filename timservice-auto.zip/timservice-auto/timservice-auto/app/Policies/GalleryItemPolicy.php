<?php

namespace App\Policies;

use App\Models\GalleryItem;
use App\Models\User;

class GalleryItemPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['admin', 'manager']);
    }

    public function view(User $user, GalleryItem $galleryItem): bool
    {
        return $user->hasAnyRole(['admin', 'manager']);
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole(['admin', 'manager']);
    }

    public function update(User $user, GalleryItem $galleryItem): bool
    {
        return $user->hasAnyRole(['admin', 'manager']);
    }

    public function delete(User $user, GalleryItem $galleryItem): bool
    {
        return $user->hasRole('admin');
    }
}
