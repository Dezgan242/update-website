<?php

namespace App\Policies;

use App\Models\Review;
use App\Models\User;

// Модерация (approve/reject) доступна admin и manager, удаление — только admin
class ReviewPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['admin', 'manager']);
    }

    public function view(User $user, Review $review): bool
    {
        return $user->hasAnyRole(['admin', 'manager']);
    }

    public function update(User $user, Review $review): bool
    {
        return $user->hasAnyRole(['admin', 'manager']);
    }

    public function delete(User $user, Review $review): bool
    {
        return $user->hasRole('admin');
    }
}
