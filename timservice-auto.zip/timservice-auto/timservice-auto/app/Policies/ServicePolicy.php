<?php

namespace App\Policies;

use App\Models\Service;
use App\Models\User;

// Услуги редактируют admin и manager, удаляет — только admin
class ServicePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['admin', 'manager']);
    }

    public function view(User $user, Service $service): bool
    {
        return $user->hasAnyRole(['admin', 'manager']);
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole(['admin', 'manager']);
    }

    public function update(User $user, Service $service): bool
    {
        return $user->hasAnyRole(['admin', 'manager']);
    }

    public function delete(User $user, Service $service): bool
    {
        return $user->hasRole('admin');
    }
}
