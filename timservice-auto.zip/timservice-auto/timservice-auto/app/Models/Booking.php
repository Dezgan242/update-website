<?php

namespace App\Models;

use App\Enums\BookingStatus;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Booking extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'name',
        'phone',
        'email',
        'car_brand',
        'car_model',
        'service_id',
        'master_id',
        'booking_date',
        'booking_time',
        'comment',
        'status',
        'source',
        'admin_notes',
        'consent_pd',
    ];

    protected function casts(): array
    {
        return [
            'status' => BookingStatus::class,
            'booking_date' => 'date',
            'consent_pd' => 'boolean',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function service(): BelongsTo
    {
        return $this->belongsTo(Service::class);
    }

    public function master(): BelongsTo
    {
        return $this->belongsTo(Master::class);
    }

    public function scopeStatus(Builder $query, BookingStatus|string $status): Builder
    {
        $value = $status instanceof BookingStatus ? $status->value : $status;

        return $query->where('status', $value);
    }

    public function scopeForDate(Builder $query, string $date): Builder
    {
        return $query->whereDate('booking_date', $date);
    }

    public function scopeUpcoming(Builder $query): Builder
    {
        return $query->where('booking_date', '>=', now()->toDateString())
            ->whereNotIn('status', [BookingStatus::Cancelled->value, BookingStatus::Completed->value]);
    }

    // Удобное строковое представление даты+времени для писем и админки
    public function getScheduledAtLabelAttribute(): string
    {
        return $this->booking_date->format('d.m.Y').' в '.substr($this->booking_time, 0, 5);
    }
}
