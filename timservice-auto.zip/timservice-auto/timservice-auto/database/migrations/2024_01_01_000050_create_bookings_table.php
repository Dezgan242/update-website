<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// Заявки на онлайн-запись: гость (user_id = null) либо зарегистрированный клиент
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('bookings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('name');
            $table->string('phone', 20);
            $table->string('email')->nullable();
            $table->string('car_brand')->nullable();
            $table->string('car_model')->nullable();
            $table->foreignId('service_id')->constrained()->restrictOnDelete();
            $table->foreignId('master_id')->nullable()->constrained()->nullOnDelete();
            $table->date('booking_date');
            $table->time('booking_time');
            $table->text('comment')->nullable();
            // Статус — строка, соответствует значению value enum'а App\Enums\BookingStatus
            $table->string('status', 20)->default('new');
            $table->string('source', 30)->default('website');
            $table->text('admin_notes')->nullable();
            $table->boolean('consent_pd')->default(false); // согласие на обработку ПД, 152-ФЗ
            $table->timestamps();

            $table->index(['booking_date', 'booking_time']);
            $table->index('status');
            $table->unique(['master_id', 'booking_date', 'booking_time'], 'uniq_master_slot');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('bookings');
    }
};
