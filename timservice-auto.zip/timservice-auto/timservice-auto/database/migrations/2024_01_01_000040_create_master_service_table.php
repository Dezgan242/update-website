<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// Pivot-таблица many-to-many: какие услуги умеет выполнять каждый мастер
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('master_service', function (Blueprint $table) {
            $table->id();
            $table->foreignId('master_id')->constrained()->cascadeOnDelete();
            $table->foreignId('service_id')->constrained()->cascadeOnDelete();
            $table->timestamps();

            $table->unique(['master_id', 'service_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('master_service');
    }
};
