<?php

namespace Database\Seeders;

use App\Models\Service;
use App\Models\ServiceCategory;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class ServiceSeeder extends Seeder
{
    public function run(): void
    {
        $services = [
            'Детейлинг' => [
                ['name' => 'Полировка кузова', 'price' => 5500, 'duration' => 180, 'popular' => true],
                ['name' => 'Керамическое покрытие', 'price' => 15000, 'duration' => 240, 'popular' => true],
                ['name' => 'Нанесение антидождя', 'price' => 1500, 'duration' => 40, 'popular' => false],
            ],
            'Химчистка салона' => [
                ['name' => 'Химчистка сидений', 'price' => 3000, 'duration' => 120, 'popular' => true],
                ['name' => 'Полная химчистка салона', 'price' => 7000, 'duration' => 240, 'popular' => true],
                ['name' => 'Чистка потолка', 'price' => 2000, 'duration' => 90, 'popular' => false],
            ],
            'Кузовной ремонт' => [
                ['name' => 'Удаление вмятины без покраски (PDR)', 'price' => 2500, 'duration' => 90, 'popular' => false],
                ['name' => 'Локальная покраска элемента', 'price' => 6000, 'duration' => 300, 'popular' => true],
                ['name' => 'Полировка фар', 'price' => 1800, 'duration' => 60, 'popular' => false],
            ],
            'Шиномонтаж' => [
                ['name' => 'Сезонная замена шин (4 колеса)', 'price' => 2000, 'duration' => 60, 'popular' => true],
                ['name' => 'Балансировка колёс', 'price' => 1200, 'duration' => 40, 'popular' => false],
                ['name' => 'Ремонт прокола', 'price' => 700, 'duration' => 30, 'popular' => false],
            ],
            'Диагностика и ТО' => [
                ['name' => 'Компьютерная диагностика', 'price' => 1500, 'duration' => 45, 'popular' => true],
                ['name' => 'Замена масла и фильтров', 'price' => 2500, 'duration' => 60, 'popular' => true],
                ['name' => 'Плановое ТО', 'price' => 4500, 'duration' => 120, 'popular' => false],
            ],
        ];

        foreach ($services as $categoryName => $items) {
            $category = ServiceCategory::where('name', $categoryName)->firstOrFail();

            foreach ($items as $i => $item) {
                Service::firstOrCreate(
                    ['slug' => Str::slug($item['name'])],
                    [
                        'category_id' => $category->id,
                        'name' => $item['name'],
                        'description' => "Услуга «{$item['name']}» выполняется опытными мастерами с использованием профессионального оборудования и материалов.",
                        'price_from' => $item['price'],
                        'duration_minutes' => $item['duration'],
                        'is_active' => true,
                        'is_popular' => $item['popular'],
                        'sort_order' => $i,
                    ]
                );
            }
        }
    }
}
