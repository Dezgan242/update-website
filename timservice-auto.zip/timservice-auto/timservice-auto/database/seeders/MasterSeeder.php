<?php

namespace Database\Seeders;

use App\Models\Master;
use Illuminate\Database\Seeder;

class MasterSeeder extends Seeder
{
    public function run(): void
    {
        $masters = [
            ['name' => 'Иван Петров', 'position' => 'Мастер детейлинга', 'experience' => 8, 'bio' => 'Специализируется на керамических покрытиях и полировке кузова.'],
            ['name' => 'Сергей Кузнецов', 'position' => 'Мастер кузовного ремонта', 'experience' => 12, 'bio' => 'Более 12 лет опыта в рихтовке и локальной покраске.'],
            ['name' => 'Анна Смирнова', 'position' => 'Специалист по химчистке', 'experience' => 5, 'bio' => 'Выводит даже самые сложные пятна и запахи из салона.'],
            ['name' => 'Дмитрий Волков', 'position' => 'Шиномонтажник', 'experience' => 6, 'bio' => 'Быстро и аккуратно меняет резину любой сложности.'],
            ['name' => 'Максим Орлов', 'position' => 'Мастер-диагност', 'experience' => 10, 'bio' => 'Диагностирует неисправности любой сложности на современном оборудовании.'],
        ];

        foreach ($masters as $i => $master) {
            Master::firstOrCreate(
                ['name' => $master['name']],
                [
                    'position' => $master['position'],
                    'experience_years' => $master['experience'],
                    'bio' => $master['bio'],
                    'is_active' => true,
                    'sort_order' => $i,
                ]
            );
        }
    }
}
