<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            'contact_phone' => ['value' => '+7 (900) 123-45-67', 'group' => 'contacts'],
            'contact_email' => ['value' => 'info@timservice-auto.local', 'group' => 'contacts'],
            'contact_address' => ['value' => 'г. Москва, ул. Автосервисная, д. 10', 'group' => 'contacts'],
            'work_hours' => ['value' => 'Пн–Вс: 09:00–20:00', 'group' => 'contacts'],
            'map_iframe' => ['value' => '', 'group' => 'contacts'],
            'social_vk' => ['value' => 'https://vk.com/timservice_auto', 'group' => 'social'],
            'social_telegram' => ['value' => 'https://t.me/timservice_auto', 'group' => 'social'],
            'social_whatsapp' => ['value' => '+79001234567', 'group' => 'social'],
            'seo_title' => ['value' => 'ТимСервис Авто — автосервис полного цикла', 'group' => 'seo'],
            'seo_description' => ['value' => 'Детейлинг, химчистка, кузовной ремонт, шиномонтаж и диагностика. Онлайн-запись за 2 минуты.', 'group' => 'seo'],
        ];

        foreach ($settings as $key => $data) {
            Setting::firstOrCreate(['key' => $key], ['value' => $data['value'], 'group' => $data['group']]);
        }
    }
}
