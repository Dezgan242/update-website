<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [
            'bookings.view', 'bookings.manage',
            'services.manage', 'masters.manage',
            'reviews.moderate', 'gallery.manage',
            'messages.view',
            'users.manage', 'roles.manage', 'settings.manage',
        ];

        foreach ($permissions as $permission) {
            Permission::firstOrCreate(['name' => $permission, 'guard_name' => 'web']);
        }

        $admin = Role::firstOrCreate(['name' => 'admin', 'guard_name' => 'web']);
        $admin->syncPermissions(Permission::all());

        $manager = Role::firstOrCreate(['name' => 'manager', 'guard_name' => 'web']);
        $manager->syncPermissions([
            'bookings.view', 'bookings.manage',
            'services.manage', 'masters.manage',
            'reviews.moderate', 'gallery.manage', 'messages.view',
        ]);

        // У клиента прав в админке нет — используется только для доступа к личному кабинету
        Role::firstOrCreate(['name' => 'client', 'guard_name' => 'web']);
    }
}
