<?php

namespace Database\Seeders;

use App\Enums\BookingStatus;
use App\Models\Booking;
use App\Models\Master;
use App\Models\Service;
use App\Models\User;
use Illuminate\Database\Seeder;

class BookingSeeder extends Seeder
{
    private const CAR_BRANDS = [
        'Toyota' => ['Camry', 'Corolla', 'RAV4'],
        'Kia' => ['Rio', 'Sportage', 'Ceed'],
        'Hyundai' => ['Solaris', 'Creta', 'Tucson'],
        'Lada' => ['Vesta', 'Granta', 'XRAY'],
        'Volkswagen' => ['Polo', 'Tiguan', 'Passat'],
        'BMW' => ['3 series', 'X5', 'X3'],
    ];

    public function run(): void
    {
        $services = Service::all();
        $masters = Master::all();
        $clients = User::role('client')->get();
        $faker = fake('ru_RU');

        // Распределяем 40 заявок: часть в прошлом (завершены/отменены), часть на ближайшие дни (новые/в работе)
        for ($i = 1; $i <= 40; $i++) {
            $service = $services->random();
            $master = $masters->random();
            $brand = array_rand(self::CAR_BRANDS);
            $model = self::CAR_BRANDS[$brand][array_rand(self::CAR_BRANDS[$brand])];

            $isPast = $i <= 25; // первые 25 — прошедшие заявки, остальные — предстоящие
            $date = $isPast
                ? now()->subDays(random_int(1, 45))
                : now()->addDays(random_int(0, 14));

            $status = $isPast
                ? fake()->randomElement([BookingStatus::Completed, BookingStatus::Completed, BookingStatus::Cancelled])
                : fake()->randomElement([BookingStatus::New, BookingStatus::New, BookingStatus::InProgress]);

            $useClient = $clients->isNotEmpty() && fake()->boolean(40);
            $client = $useClient ? $clients->random() : null;

            try {
                Booking::create([
                    'user_id' => $client?->id,
                    'name' => $client?->name ?? $faker->name(),
                    'phone' => $client?->phone ?? $faker->phoneNumber(),
                    'email' => $client?->email ?? (fake()->boolean(60) ? $faker->safeEmail() : null),
                    'car_brand' => $brand,
                    'car_model' => $model,
                    'service_id' => $service->id,
                    'master_id' => fake()->boolean(80) ? $master->id : null,
                    'booking_date' => $date->toDateString(),
                    'booking_time' => sprintf('%02d:00', random_int(9, 18)),
                    'comment' => fake()->boolean(30) ? $faker->sentence(8) : null,
                    'status' => $status,
                    'source' => fake()->randomElement(['website', 'website', 'phone', 'admin']),
                    'consent_pd' => true,
                ]);
            } catch (\Illuminate\Database\QueryException $e) {
                // Случайно сгенерированный дубль слота (мастер+дата+время) — просто пропускаем эту заявку
                continue;
            }
        }
    }
}
