<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            RolePermissionSeeder::class,
            UserSeeder::class,
            ServiceCategorySeeder::class,
            ServiceSeeder::class,
            MasterSeeder::class,
            MasterServiceSeeder::class,
            SettingSeeder::class,
            BookingSeeder::class,
            ReviewSeeder::class,
            GalleryItemSeeder::class,
        ]);

        $this->command?->info('База данных заполнена демо-данными.');
        $this->command?->info('Админ: admin@timservice-auto.local / password');
        $this->command?->info('Менеджер: manager@timservice-auto.local / password');
    }
}
