<?php

namespace Database\Seeders;

use App\Models\ServiceCategory;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class ServiceCategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name' => 'Детейлинг', 'description' => 'Полировка, керамика, защита кузова.'],
            ['name' => 'Химчистка салона', 'description' => 'Глубокая чистка сидений, потолка, ковров.'],
            ['name' => 'Кузовной ремонт', 'description' => 'Рихтовка, покраска, устранение вмятин.'],
            ['name' => 'Шиномонтаж', 'description' => 'Сезонная замена шин, балансировка, ремонт проколов.'],
            ['name' => 'Диагностика и ТО', 'description' => 'Компьютерная диагностика, плановое обслуживание.'],
        ];

        foreach ($categories as $i => $category) {
            ServiceCategory::firstOrCreate(
                ['slug' => Str::slug($category['name'])],
                [
                    'name' => $category['name'],
                    'description' => $category['description'],
                    'sort_order' => $i,
                    'is_active' => true,
                ]
            );
        }
    }
}
