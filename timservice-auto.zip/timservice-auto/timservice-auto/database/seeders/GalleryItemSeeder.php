<?php

namespace Database\Seeders;

use App\Models\GalleryItem;
use App\Models\ServiceCategory;
use Illuminate\Database\Seeder;

class GalleryItemSeeder extends Seeder
{
    private const ITEMS = [
        ['title' => 'Полировка кузова BMW 3 series', 'category' => 'Детейлинг'],
        ['title' => 'Керамика на Toyota Camry', 'category' => 'Детейлинг'],
        ['title' => 'Химчистка салона Kia Sportage', 'category' => 'Химчистка салона'],
        ['title' => 'Удаление запаха в Hyundai Solaris', 'category' => 'Химчистка салона'],
        ['title' => 'Ремонт бампера Lada Vesta', 'category' => 'Кузовной ремонт'],
        ['title' => 'Покраска крыла Volkswagen Passat', 'category' => 'Кузовной ремонт'],
        ['title' => 'Замена резины на Hyundai Creta', 'category' => 'Шиномонтаж'],
        ['title' => 'Полировка фар Kia Rio', 'category' => 'Детейлинг'],
    ];

    public function run(): void
    {
        foreach (self::ITEMS as $i => $item) {
            $category = ServiceCategory::where('name', $item['category'])->first();

            GalleryItem::firstOrCreate(
                ['title' => $item['title']],
                [
                    'service_category_id' => $category?->id,
                    'description' => 'Работа выполнена нашими мастерами. Фото до и после — реальный результат.',
                    'is_published' => true,
                    'sort_order' => $i,
                ]
            );
        }

        // Изображения не прикладываются сидером (нет исходников/интернета в среде сборки) —
        // модель отдаёт заглушку через getBeforeUrlAttribute()/getAfterUrlAttribute(),
        // реальные фото загружаются через админку (drag&drop, Spatie Media Library).
    }
}
