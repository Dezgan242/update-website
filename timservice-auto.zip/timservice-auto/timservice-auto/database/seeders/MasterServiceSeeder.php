<?php

namespace Database\Seeders;

use App\Models\Master;
use App\Models\Service;
use Illuminate\Database\Seeder;

class MasterServiceSeeder extends Seeder
{
    // Соответствие «мастер => категория его услуг» — логично привязываем по специализации
    private const MAP = [
        'Иван Петров' => 'Детейлинг',
        'Сергей Кузнецов' => 'Кузовной ремонт',
        'Анна Смирнова' => 'Химчистка салона',
        'Дмитрий Волков' => 'Шиномонтаж',
        'Максим Орлов' => 'Диагностика и ТО',
    ];

    public function run(): void
    {
        foreach (self::MAP as $masterName => $categoryName) {
            $master = Master::where('name', $masterName)->first();
            $serviceIds = Service::whereHas('category', fn ($q) => $q->where('name', $categoryName))->pluck('id');

            if ($master && $serviceIds->isNotEmpty()) {
                $master->services()->syncWithoutDetaching($serviceIds);
            }
        }
    }
}
