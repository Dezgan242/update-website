<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $admin = User::firstOrCreate(
            ['email' => 'admin@timservice-auto.local'],
            [
                'name' => 'Администратор',
                'phone' => '+7 900 000-00-01',
                'password' => Hash::make('password'),
                'email_verified_at' => now(),
            ]
        );
        $admin->syncRoles(['admin']);

        $manager = User::firstOrCreate(
            ['email' => 'manager@timservice-auto.local'],
            [
                'name' => 'Менеджер Ольга',
                'phone' => '+7 900 000-00-02',
                'password' => Hash::make('password'),
                'email_verified_at' => now(),
            ]
        );
        $manager->syncRoles(['manager']);

        // Несколько демо-клиентов для наглядности личного кабинета и связи с заявками/отзывами
        $clients = collect(range(1, 8))->map(function (int $i) {
            $user = User::firstOrCreate(
                ['email' => "client{$i}@timservice-auto.local"],
                [
                    'name' => fake('ru_RU')->name(),
                    'phone' => fake('ru_RU')->phoneNumber(),
                    'password' => Hash::make('password'),
                    'email_verified_at' => now(),
                ]
            );
            $user->syncRoles(['client']);

            return $user;
        });

        $this->command?->info('Клиентов создано: '.$clients->count());
    }
}
