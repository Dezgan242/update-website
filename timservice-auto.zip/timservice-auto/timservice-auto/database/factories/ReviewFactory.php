<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Review>
 */
class ReviewFactory extends Factory
{
    public function definition(): array
    {
        return [
            'name' => fake('ru_RU')->name(),
            'phone' => fake('ru_RU')->phoneNumber(),
            'email' => fake()->boolean(50) ? fake()->safeEmail() : null,
            'rating' => fake()->numberBetween(1, 5),
            'text' => fake('ru_RU')->sentence(15),
            'is_approved' => fake()->boolean(70),
            'consent_pd' => true,
        ];
    }
}
