<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Master>
 */
class MasterFactory extends Factory
{
    public function definition(): array
    {
        return [
            'name' => fake('ru_RU')->name('male'),
            'position' => fake('ru_RU')->randomElement(['Мастер детейлинга', 'Специалист по химчистке', 'Мастер кузовного ремонта', 'Шиномонтажник', 'Диагност']),
            'experience_years' => fake()->numberBetween(1, 20),
            'bio' => fake('ru_RU')->sentence(10),
            'is_active' => true,
            'sort_order' => 0,
        ];
    }
}
