<?php

namespace Database\Factories;

use App\Enums\BookingStatus;
use App\Models\Service;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Booking>
 */
class BookingFactory extends Factory
{
    public function definition(): array
    {
        return [
            'name' => fake('ru_RU')->name(),
            'phone' => fake('ru_RU')->phoneNumber(),
            'email' => fake()->boolean(60) ? fake()->safeEmail() : null,
            'car_brand' => fake()->randomElement(['Toyota', 'Kia', 'Hyundai', 'Lada', 'Volkswagen']),
            'car_model' => fake()->word(),
            'service_id' => Service::factory(),
            'booking_date' => fake()->dateTimeBetween('-30 days', '+14 days')->format('Y-m-d'),
            'booking_time' => sprintf('%02d:00', fake()->numberBetween(9, 18)),
            'comment' => fake()->boolean(30) ? fake('ru_RU')->sentence() : null,
            'status' => fake()->randomElement(BookingStatus::cases()),
            'source' => 'website',
            'consent_pd' => true,
        ];
    }
}
