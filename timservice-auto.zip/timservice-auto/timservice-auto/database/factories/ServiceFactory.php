<?php

namespace Database\Factories;

use App\Models\ServiceCategory;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Service>
 */
class ServiceFactory extends Factory
{
    public function definition(): array
    {
        $name = fake('ru_RU')->words(3, true);

        return [
            'category_id' => ServiceCategory::factory(),
            'name' => $name,
            'slug' => Str::slug($name).'-'.fake()->unique()->numberBetween(1, 100000),
            'description' => fake('ru_RU')->sentence(12),
            'price_from' => fake()->numberBetween(500, 15000),
            'duration_minutes' => fake()->randomElement([30, 45, 60, 90, 120, 180]),
            'is_active' => true,
            'is_popular' => fake()->boolean(30),
            'sort_order' => 0,
        ];
    }
}
