import './bootstrap';
import Alpine from 'alpinejs';

window.Alpine = Alpine;

// Директива x-fade-in — добавляет класс is-visible, когда элемент попадает во вьюпорт
// (используется вместо тяжёлых анимационных библиотек для появления секций)
Alpine.directive('fade-in', (el) => {
    const observer = new IntersectionObserver(
        (entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        },
        { threshold: 0.1 }
    );

    el.classList.add('fade-in-up');
    observer.observe(el);
});

// Глобальный стор для toast-уведомлений — компонент x-data="toasts" слушает событие 'notify'
Alpine.store('toasts', {
    items: [],
    push(message, type = 'success') {
        const id = Date.now();
        this.items.push({ id, message, type });
        setTimeout(() => this.remove(id), 4000);
    },
    remove(id) {
        this.items = this.items.filter((t) => t.id !== id);
    },
});

Alpine.start();
