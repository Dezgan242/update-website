@extends('layouts.app')

@section('content')
<section class="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-bold text-navy-900">Отзывы наших клиентов</h1>

    <div class="mt-8 grid gap-8 lg:grid-cols-3">
        <div class="lg:col-span-2">
            <div class="space-y-4">
                @forelse($reviews as $review)
                    <x-card>
                        <div class="flex items-center justify-between">
                            <p class="font-semibold text-navy-900">{{ $review->name }}</p>
                            <div class="flex text-accent-500">
                                @for($i = 0; $i < 5; $i++){{ $i < $review->rating ? '★' : '☆' }}@endfor
                            </div>
                        </div>
                        @if($review->service)
                            <p class="mt-1 text-xs uppercase tracking-wide text-navy-400">{{ $review->service->name }}</p>
                        @endif
                        <p class="mt-3 text-sm text-navy-700">{{ $review->text }}</p>
                        <p class="mt-2 text-xs text-navy-400">{{ $review->created_at->format('d.m.Y') }}</p>
                    </x-card>
                @empty
                    <p class="text-navy-500">Пока нет отзывов — станьте первым!</p>
                @endforelse
            </div>

            <div class="mt-8">{{ $reviews->links() }}</div>
        </div>

        <div>
            <x-card>
                <h2 class="mb-4 text-lg font-semibold text-navy-900">Оставить отзыв</h2>

                @if(session('success'))
                    <x-alert type="success" class="mb-4">{{ session('success') }}</x-alert>
                @endif

                <form method="POST" action="{{ route('reviews.store') }}" class="space-y-4" x-data="{ rating: 5 }">
                    @csrf
                    {{-- honeypot: обычные пользователи это поле не видят --}}
                    <input type="text" name="website" tabindex="-1" autocomplete="off" class="hidden" aria-hidden="true">

                    <x-input name="name" label="Ваше имя" required />
                    <x-input name="phone" label="Телефон" />
                    <x-input name="email" type="email" label="Email" />
                    <x-select name="service_id" label="Услуга (необязательно)" :options="$services->pluck('name', 'id')" placeholder="Не выбрано" />

                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-navy-800">Оценка</label>
                        <div class="flex gap-1 text-2xl text-accent-500">
                            <template x-for="star in [1,2,3,4,5]" :key="star">
                                <button type="button" x-on:click="rating = star" x-text="star <= rating ? '★' : '☆'"></button>
                            </template>
                        </div>
                        <input type="hidden" name="rating" :value="rating">
                    </div>

                    <x-textarea name="text" label="Ваш отзыв" required />

                    <label class="flex items-start gap-2 text-xs text-navy-500">
                        <input type="checkbox" name="consent_pd" value="1" required class="mt-0.5 rounded border-navy-300">
                        Согласен(-на) на обработку персональных данных
                    </label>

                    <x-button type="submit" class="w-full">Отправить отзыв</x-button>
                </form>
            </x-card>
        </div>
    </div>
</section>
@endsection
