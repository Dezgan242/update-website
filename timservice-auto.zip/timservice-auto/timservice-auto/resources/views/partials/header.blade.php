<header class="sticky top-0 z-40 bg-white/95 backdrop-blur shadow-sm" x-data="{ mobileOpen: false }">
    <div class="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <a href="{{ route('home') }}" class="flex items-center gap-2 text-xl font-bold text-navy-900">
            <span class="rounded-lg bg-navy-900 px-2 py-1 text-accent-500">ТС</span>
            ТимСервис Авто
        </a>

        <nav class="hidden items-center gap-6 md:flex">
            <x-nav-link href="{{ route('services.index') }}" :active="request()->routeIs('services.*')">Услуги</x-nav-link>
            <x-nav-link href="{{ route('about') }}" :active="request()->routeIs('about')">О нас</x-nav-link>
            <x-nav-link href="{{ route('gallery.index') }}" :active="request()->routeIs('gallery.*')">Галерея</x-nav-link>
            <x-nav-link href="{{ route('reviews.index') }}" :active="request()->routeIs('reviews.*')">Отзывы</x-nav-link>
            <x-nav-link href="{{ route('contacts.index') }}" :active="request()->routeIs('contacts.*')">Контакты</x-nav-link>
        </nav>

        <div class="hidden items-center gap-3 md:flex">
            @auth
                <a href="{{ route('dashboard') }}" class="text-sm font-medium text-navy-700 hover:text-accent-500">
                    Личный кабинет
                </a>
            @else
                <a href="{{ route('login') }}" class="text-sm font-medium text-navy-700 hover:text-accent-500">Войти</a>
            @endauth
            <a href="{{ route('booking.create') }}" class="inline-flex items-center justify-center gap-2 rounded-lg bg-accent-500 px-5 py-2 text-sm font-semibold text-white transition hover:bg-accent-600">
                Записаться
            </a>
        </div>

        <button type="button" class="text-navy-800 md:hidden" x-on:click="mobileOpen = !mobileOpen" aria-label="Меню">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
        </button>
    </div>

    <div x-show="mobileOpen" x-cloak x-transition class="border-t border-navy-100 px-4 pb-4 md:hidden">
        <nav class="flex flex-col gap-3 pt-3">
            <x-nav-link href="{{ route('services.index') }}">Услуги</x-nav-link>
            <x-nav-link href="{{ route('about') }}">О нас</x-nav-link>
            <x-nav-link href="{{ route('gallery.index') }}">Галерея</x-nav-link>
            <x-nav-link href="{{ route('reviews.index') }}">Отзывы</x-nav-link>
            <x-nav-link href="{{ route('contacts.index') }}">Контакты</x-nav-link>
            @auth
                <x-nav-link href="{{ route('dashboard') }}">Личный кабинет</x-nav-link>
            @else
                <x-nav-link href="{{ route('login') }}">Войти</x-nav-link>
            @endauth
            <a href="{{ route('booking.create') }}" class="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-accent-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-accent-600">
                Записаться
            </a>
        </nav>
    </div>
</header>
