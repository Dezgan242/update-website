@php
$seoTitle = $seoTitle ?? \App\Models\Setting::get('seo_title', config('app.name'));
$seoDescription = $seoDescription ?? \App\Models\Setting::get('seo_description', '');
@endphp

<title>{{ $seoTitle }}</title>
<meta name="description" content="{{ $seoDescription }}">
<meta property="og:title" content="{{ $seoTitle }}">
<meta property="og:description" content="{{ $seoDescription }}">
<meta property="og:type" content="website">

{{-- Schema.org: LocalBusiness — помогает поисковикам показывать карточку организации --}}
<script type="application/ld+json">
{!! json_encode([
    '@context' => 'https://schema.org',
    '@type' => 'AutoRepair',
    'name' => config('app.name'),
    'telephone' => \App\Models\Setting::get('contact_phone'),
    'email' => \App\Models\Setting::get('contact_email'),
    'address' => \App\Models\Setting::get('contact_address'),
    'openingHours' => \App\Models\Setting::get('work_hours'),
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!}
</script>
