<footer class="mt-20 bg-navy-900 text-navy-200">
    <div class="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-4 lg:px-8">
        <div>
            <div class="flex items-center gap-2 text-xl font-bold text-white">
                <span class="rounded-lg bg-accent-500 px-2 py-1 text-white">ТС</span>
                ТимСервис Авто
            </div>
            <p class="mt-3 text-sm text-navy-300">Автосервис полного цикла: детейлинг, химчистка, кузовной ремонт, шиномонтаж и диагностика.</p>
        </div>

        <div>
            <h4 class="mb-3 text-sm font-semibold uppercase tracking-wide text-white">Навигация</h4>
            <ul class="space-y-2 text-sm">
                <li><a href="{{ route('services.index') }}" class="hover:text-accent-400">Услуги</a></li>
                <li><a href="{{ route('about') }}" class="hover:text-accent-400">О нас</a></li>
                <li><a href="{{ route('gallery.index') }}" class="hover:text-accent-400">Галерея</a></li>
                <li><a href="{{ route('reviews.index') }}" class="hover:text-accent-400">Отзывы</a></li>
            </ul>
        </div>

        <div>
            <h4 class="mb-3 text-sm font-semibold uppercase tracking-wide text-white">Контакты</h4>
            <ul class="space-y-2 text-sm">
                <li>{{ $globalContacts['contact_phone'] ?? \App\Models\Setting::get('contact_phone') }}</li>
                <li>{{ $globalContacts['contact_email'] ?? \App\Models\Setting::get('contact_email') }}</li>
                <li>{{ $globalContacts['contact_address'] ?? \App\Models\Setting::get('contact_address') }}</li>
                <li>{{ $globalContacts['work_hours'] ?? \App\Models\Setting::get('work_hours') }}</li>
            </ul>
        </div>

        <div>
            <h4 class="mb-3 text-sm font-semibold uppercase tracking-wide text-white">Мы в соцсетях</h4>
            <ul class="space-y-2 text-sm">
                @php $socials = $globalSocials ?? \App\Models\Setting::group('social'); @endphp
                @if(!empty($socials['social_vk']))
                    <li><a href="{{ $socials['social_vk'] }}" target="_blank" class="hover:text-accent-400">VK</a></li>
                @endif
                @if(!empty($socials['social_telegram']))
                    <li><a href="{{ $socials['social_telegram'] }}" target="_blank" class="hover:text-accent-400">Telegram</a></li>
                @endif
                @if(!empty($socials['social_whatsapp']))
                    <li><a href="https://wa.me/{{ preg_replace('/\D/', '', $socials['social_whatsapp']) }}" target="_blank" class="hover:text-accent-400">WhatsApp</a></li>
                @endif
            </ul>
        </div>
    </div>

    <div class="border-t border-navy-800 py-4 text-center text-xs text-navy-400">
        &copy; {{ now()->year }} ТимСервис Авто. Все права защищены.
    </div>
</footer>
