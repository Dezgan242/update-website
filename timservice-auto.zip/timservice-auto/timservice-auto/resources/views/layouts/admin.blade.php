<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Админ-панель') — {{ config('app.name') }}</title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=manrope:400,500,600,700,800" rel="stylesheet" />

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-navy-50 font-sans text-navy-900 antialiased" x-data="{ sidebarOpen: false }">
    <x-toast />

    <div class="flex min-h-screen">
        {{-- Sidebar --}}
        <aside
            class="fixed inset-y-0 left-0 z-30 w-64 -translate-x-full transform bg-navy-900 text-navy-200 transition-transform duration-200 lg:static lg:translate-x-0"
            :class="sidebarOpen && '!translate-x-0'"
        >
            <div class="flex h-16 items-center gap-2 px-6 text-lg font-bold text-white">
                <span class="rounded-lg bg-accent-500 px-2 py-1">ТС</span>
                Админка
            </div>

            <nav class="space-y-6 px-4 py-4 text-sm">
                <div>
                    <p class="mb-2 px-2 text-xs font-semibold uppercase tracking-wide text-navy-500">Обзор</p>
                    <a href="{{ route('admin.dashboard') }}" class="flex items-center gap-2 rounded-lg px-3 py-2 {{ request()->routeIs('admin.dashboard') ? 'bg-navy-800 text-white' : 'hover:bg-navy-800 hover:text-white' }}">Дашборд</a>
                </div>

                <div>
                    <p class="mb-2 px-2 text-xs font-semibold uppercase tracking-wide text-navy-500">Каталог</p>
                    <a href="{{ route('admin.categories.index') }}" class="flex items-center gap-2 rounded-lg px-3 py-2 {{ request()->routeIs('admin.categories.*') ? 'bg-navy-800 text-white' : 'hover:bg-navy-800 hover:text-white' }}">Категории</a>
                    <a href="{{ route('admin.services.index') }}" class="flex items-center gap-2 rounded-lg px-3 py-2 {{ request()->routeIs('admin.services.*') ? 'bg-navy-800 text-white' : 'hover:bg-navy-800 hover:text-white' }}">Услуги</a>
                    <a href="{{ route('admin.masters.index') }}" class="flex items-center gap-2 rounded-lg px-3 py-2 {{ request()->routeIs('admin.masters.*') ? 'bg-navy-800 text-white' : 'hover:bg-navy-800 hover:text-white' }}">Мастера</a>
                    <a href="{{ route('admin.gallery.index') }}" class="flex items-center gap-2 rounded-lg px-3 py-2 {{ request()->routeIs('admin.gallery.*') ? 'bg-navy-800 text-white' : 'hover:bg-navy-800 hover:text-white' }}">Галерея</a>
                </div>

                <div>
                    <p class="mb-2 px-2 text-xs font-semibold uppercase tracking-wide text-navy-500">Заявки</p>
                    <a href="{{ route('admin.bookings.index') }}" class="flex items-center gap-2 rounded-lg px-3 py-2 {{ request()->routeIs('admin.bookings.index') || request()->routeIs('admin.bookings.edit') ? 'bg-navy-800 text-white' : 'hover:bg-navy-800 hover:text-white' }}">Список заявок</a>
                    <a href="{{ route('admin.bookings.calendar') }}" class="flex items-center gap-2 rounded-lg px-3 py-2 {{ request()->routeIs('admin.bookings.calendar') ? 'bg-navy-800 text-white' : 'hover:bg-navy-800 hover:text-white' }}">Календарь</a>
                    <a href="{{ route('admin.reviews.index') }}" class="flex items-center gap-2 rounded-lg px-3 py-2 {{ request()->routeIs('admin.reviews.*') ? 'bg-navy-800 text-white' : 'hover:bg-navy-800 hover:text-white' }}">Отзывы</a>
                    <a href="{{ route('admin.messages.index') }}" class="flex items-center gap-2 rounded-lg px-3 py-2 {{ request()->routeIs('admin.messages.*') ? 'bg-navy-800 text-white' : 'hover:bg-navy-800 hover:text-white' }}">Обращения</a>
                </div>

                @role('admin')
                <div>
                    <p class="mb-2 px-2 text-xs font-semibold uppercase tracking-wide text-navy-500">Система</p>
                    <a href="{{ route('admin.users.index') }}" class="flex items-center gap-2 rounded-lg px-3 py-2 {{ request()->routeIs('admin.users.*') ? 'bg-navy-800 text-white' : 'hover:bg-navy-800 hover:text-white' }}">Пользователи</a>
                    <a href="{{ route('admin.roles.index') }}" class="flex items-center gap-2 rounded-lg px-3 py-2 {{ request()->routeIs('admin.roles.*') ? 'bg-navy-800 text-white' : 'hover:bg-navy-800 hover:text-white' }}">Роли и права</a>
                    <a href="{{ route('admin.settings.edit') }}" class="flex items-center gap-2 rounded-lg px-3 py-2 {{ request()->routeIs('admin.settings.*') ? 'bg-navy-800 text-white' : 'hover:bg-navy-800 hover:text-white' }}">Настройки сайта</a>
                </div>
                @endrole
            </nav>
        </aside>

        <div x-show="sidebarOpen" x-cloak class="fixed inset-0 z-20 bg-navy-900/50 lg:hidden" x-on:click="sidebarOpen = false"></div>

        {{-- Main --}}
        <div class="flex min-h-screen flex-1 flex-col lg:pl-0">
            <header class="flex h-16 items-center justify-between border-b border-navy-100 bg-white px-4 sm:px-6">
                <div class="flex items-center gap-3">
                    <button type="button" class="text-navy-700 lg:hidden" x-on:click="sidebarOpen = !sidebarOpen">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        </svg>
                    </button>

                    <nav class="hidden text-sm text-navy-500 sm:block">
                        <a href="{{ route('admin.dashboard') }}" class="hover:text-navy-800">Админка</a>
                        @yield('breadcrumbs')
                    </nav>
                </div>

                <div class="flex items-center gap-4">
                    <a href="{{ route('home') }}" target="_blank" class="text-sm text-navy-500 hover:text-navy-800">На сайт →</a>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="text-sm font-medium text-navy-700 hover:text-accent-500">
                            {{ auth()->user()->name }} · Выйти
                        </button>
                    </form>
                </div>
            </header>

            <main class="flex-1 px-4 py-6 sm:px-6 lg:px-8">
                @yield('content')
            </main>
        </div>
    </div>

    @stack('scripts')
</body>
</html>
