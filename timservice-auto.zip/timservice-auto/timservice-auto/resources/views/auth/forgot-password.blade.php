@extends('layouts.guest')

@section('content')
<h1 class="mb-4 text-xl font-bold text-navy-900">Восстановление пароля</h1>
<p class="mb-6 text-sm text-navy-500">Укажите email — мы отправим ссылку для сброса пароля.</p>

<form method="POST" action="{{ route('password.email') }}" class="space-y-4">
    @csrf
    <x-input name="email" type="email" label="Email" required autofocus />
    <x-button type="submit" class="w-full">Отправить ссылку</x-button>
</form>
@endsection
