@extends('layouts.guest')

@section('content')
<h1 class="mb-6 text-xl font-bold text-navy-900">Новый пароль</h1>

<form method="POST" action="{{ route('password.store') }}" class="space-y-4">
    @csrf
    <input type="hidden" name="token" value="{{ $request->route('token') }}">
    <x-input name="email" type="email" label="Email" :value="old('email', $request->email)" required autofocus />
    <x-input name="password" type="password" label="Новый пароль" required />
    <x-input name="password_confirmation" type="password" label="Подтверждение пароля" required />
    <x-button type="submit" class="w-full">Сохранить пароль</x-button>
</form>
@endsection
