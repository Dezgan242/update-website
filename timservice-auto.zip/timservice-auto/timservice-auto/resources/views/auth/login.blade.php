@extends('layouts.guest')

@section('content')
<h1 class="mb-6 text-xl font-bold text-navy-900">Вход в личный кабинет</h1>

<form method="POST" action="{{ route('login') }}" class="space-y-4">
    @csrf

    <x-input name="email" type="email" label="Email" required autofocus />
    <x-input name="password" type="password" label="Пароль" required />

    <label class="flex items-center gap-2 text-sm text-navy-600">
        <input type="checkbox" name="remember" class="rounded border-navy-300">
        Запомнить меня
    </label>

    <x-button type="submit" class="w-full">Войти</x-button>

    <div class="flex items-center justify-between text-sm">
        @if (Route::has('password.request'))
            <a href="{{ route('password.request') }}" class="text-navy-500 hover:text-accent-500">Забыли пароль?</a>
        @endif
        <a href="{{ route('register') }}" class="text-navy-500 hover:text-accent-500">Регистрация</a>
    </div>
</form>
@endsection
