@extends('layouts.guest')

@section('content')
<h1 class="mb-6 text-xl font-bold text-navy-900">Регистрация</h1>

<form method="POST" action="{{ route('register') }}" class="space-y-4">
    @csrf

    <x-input name="name" label="Имя" required autofocus />
    <x-input name="phone" label="Телефон" />
    <x-input name="email" type="email" label="Email" required />
    <x-input name="password" type="password" label="Пароль" required />
    <x-input name="password_confirmation" type="password" label="Подтверждение пароля" required />

    <x-button type="submit" class="w-full">Зарегистрироваться</x-button>

    <p class="text-center text-sm text-navy-500">
        Уже есть аккаунт? <a href="{{ route('login') }}" class="text-accent-500 hover:text-accent-600">Войти</a>
    </p>
</form>
@endsection
