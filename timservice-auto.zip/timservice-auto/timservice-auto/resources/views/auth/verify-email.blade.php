@extends('layouts.guest')

@section('content')
<h1 class="mb-4 text-xl font-bold text-navy-900">Подтвердите email</h1>
<p class="mb-6 text-sm text-navy-500">Мы отправили ссылку для подтверждения на ваш email. Если письмо не пришло, запросите его повторно.</p>

@if (session('status') === 'verification-link-sent')
    <x-alert type="success" class="mb-4">Новая ссылка отправлена на указанный при регистрации email.</x-alert>
@endif

<div class="flex items-center justify-between">
    <form method="POST" action="{{ route('verification.send') }}">
        @csrf
        <x-button type="submit">Отправить письмо ещё раз</x-button>
    </form>

    <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button type="submit" class="text-sm text-navy-500 hover:text-accent-500">Выйти</button>
    </form>
</div>
@endsection
