@extends('layouts.guest')

@section('content')
<h1 class="mb-4 text-xl font-bold text-navy-900">Подтверждение пароля</h1>
<p class="mb-6 text-sm text-navy-500">Это защищённая зона — подтвердите пароль перед продолжением.</p>

<form method="POST" action="{{ route('password.confirm') }}" class="space-y-4">
    @csrf
    <x-input name="password" type="password" label="Пароль" required autofocus />
    <x-button type="submit" class="w-full">Подтвердить</x-button>
</form>
@endsection
