@extends('layouts.app')

@section('content')
<section class="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-bold text-navy-900">Примеры наших работ</h1>
    <p class="mt-2 text-navy-600">Реальные результаты — фото до и после.</p>

    <div class="mt-6 flex flex-wrap gap-2">
        <a href="{{ route('gallery.index') }}" class="rounded-full px-4 py-2 text-sm font-medium {{ request('category') ? 'bg-navy-100 text-navy-700' : 'bg-accent-500 text-white' }}">Все</a>
        @foreach($categories as $category)
            <a href="{{ route('gallery.index', ['category' => $category->slug]) }}" class="rounded-full px-4 py-2 text-sm font-medium {{ request('category') === $category->slug ? 'bg-accent-500 text-white' : 'bg-navy-100 text-navy-700 hover:bg-navy-200' }}">
                {{ $category->name }}
            </a>
        @endforeach
    </div>

    <div class="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        @foreach($items as $item)
            <x-card padding="p-4" x-data="{ showAfter: false }">
                <div class="relative aspect-video overflow-hidden rounded-xl">
                    <img :src="showAfter ? '{{ $item->after_url }}' : '{{ $item->before_url }}'" alt="{{ $item->title }}" class="h-full w-full object-cover">
                    <span class="absolute left-2 top-2 rounded-full bg-navy-900/80 px-3 py-1 text-xs font-medium text-white" x-text="showAfter ? 'После' : 'До'"></span>
                </div>
                <button type="button" x-on:click="showAfter = !showAfter" class="mt-3 text-sm font-medium text-accent-500 hover:text-accent-600">
                    Показать <span x-text="showAfter ? '«до»' : '«после»'"></span> →
                </button>
                <h3 class="mt-2 font-semibold text-navy-900">{{ $item->title }}</h3>
                @if($item->description)
                    <p class="mt-1 text-sm text-navy-600">{{ $item->description }}</p>
                @endif
            </x-card>
        @endforeach
    </div>

    <div class="mt-10">
        {{ $items->links() }}
    </div>
</section>
@endsection
