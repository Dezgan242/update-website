@props(['classes' => 'bg-navy-100 text-navy-700'])

<span {{ $attributes->merge(['class' => 'inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium '.$classes]) }}>
    {{ $slot }}
</span>
