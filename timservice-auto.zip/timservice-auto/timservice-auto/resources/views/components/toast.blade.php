<div
    x-data
    class="pointer-events-none fixed inset-x-0 top-4 z-[60] flex flex-col items-center gap-2 px-4"
>
    @if(session('success'))
        <div
            x-data="{ show: true }"
            x-show="show"
            x-init="setTimeout(() => show = false, 4000)"
            x-transition
            class="pointer-events-auto w-full max-w-sm rounded-lg bg-green-600 px-4 py-3 text-sm text-white shadow-lg"
        >
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div
            x-data="{ show: true }"
            x-show="show"
            x-init="setTimeout(() => show = false, 4000)"
            x-transition
            class="pointer-events-auto w-full max-w-sm rounded-lg bg-red-600 px-4 py-3 text-sm text-white shadow-lg"
        >
            {{ session('error') }}
        </div>
    @endif

    <template x-for="toast in $store.toasts.items" :key="toast.id">
        <div
            x-show="true"
            x-transition
            class="pointer-events-auto w-full max-w-sm rounded-lg px-4 py-3 text-sm text-white shadow-lg"
            :class="toast.type === 'error' ? 'bg-red-600' : 'bg-green-600'"
            x-text="toast.message"
        ></div>
    </template>
</div>
