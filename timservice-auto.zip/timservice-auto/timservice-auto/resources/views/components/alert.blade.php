@props(['type' => 'info'])

@php
$styles = [
    'success' => 'bg-green-50 text-green-800 ring-green-200',
    'error' => 'bg-red-50 text-red-800 ring-red-200',
    'info' => 'bg-navy-50 text-navy-800 ring-navy-200',
    'warning' => 'bg-amber-50 text-amber-800 ring-amber-200',
][$type] ?? 'bg-navy-50 text-navy-800 ring-navy-200';
@endphp

<div {{ $attributes->merge(['class' => 'rounded-lg px-4 py-3 text-sm ring-1 '.$styles]) }} role="alert">
    {{ $slot }}
</div>
