@props(['padding' => 'p-6'])

<div {{ $attributes->merge(['class' => 'rounded-2xl bg-white shadow-sm ring-1 ring-navy-100 '.$padding]) }}>
    {{ $slot }}
</div>
