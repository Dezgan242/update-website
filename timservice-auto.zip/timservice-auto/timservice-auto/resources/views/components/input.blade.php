@props(['label' => null, 'name', 'type' => 'text', 'value' => null, 'required' => false])

<div>
    @if($label)
        <label for="{{ $name }}" class="mb-1.5 block text-sm font-medium text-navy-800">
            {{ $label }} @if($required)<span class="text-accent-500">*</span>@endif
        </label>
    @endif

    <input
        type="{{ $type }}"
        name="{{ $name }}"
        id="{{ $name }}"
        value="{{ old($name, $value) }}"
        {{ $required ? 'required' : '' }}
        {{ $attributes->merge(['class' => 'block w-full rounded-lg border-navy-200 shadow-sm focus:border-accent-500 focus:ring-accent-500 sm:text-sm '.($errors->has($name) ? 'border-red-400' : '')]) }}
    >

    @error($name)
        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
    @enderror
</div>
