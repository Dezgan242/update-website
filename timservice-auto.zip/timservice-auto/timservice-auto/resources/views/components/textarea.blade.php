@props(['label' => null, 'name', 'value' => null, 'rows' => 4, 'required' => false])

<div>
    @if($label)
        <label for="{{ $name }}" class="mb-1.5 block text-sm font-medium text-navy-800">
            {{ $label }} @if($required)<span class="text-accent-500">*</span>@endif
        </label>
    @endif

    <textarea
        name="{{ $name }}"
        id="{{ $name }}"
        rows="{{ $rows }}"
        {{ $required ? 'required' : '' }}
        {{ $attributes->merge(['class' => 'block w-full rounded-lg border-navy-200 shadow-sm focus:border-accent-500 focus:ring-accent-500 sm:text-sm '.($errors->has($name) ? 'border-red-400' : '')]) }}
    >{{ old($name, $value) }}</textarea>

    @error($name)
        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
    @enderror
</div>
