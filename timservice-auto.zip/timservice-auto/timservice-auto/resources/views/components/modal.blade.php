@props(['name', 'title' => null, 'maxWidth' => 'md'])

@php
$maxWidthClass = [
    'sm' => 'sm:max-w-sm',
    'md' => 'sm:max-w-md',
    'lg' => 'sm:max-w-lg',
    'xl' => 'sm:max-w-xl',
][$maxWidth] ?? 'sm:max-w-md';
@endphp

<div
    x-data="{ open: false }"
    x-on:open-modal.window="if ($event.detail === '{{ $name }}') open = true"
    x-on:close-modal.window="if (!$event.detail || $event.detail === '{{ $name }}') open = false"
    x-on:keydown.escape.window="open = false"
    x-show="open"
    x-cloak
    class="fixed inset-0 z-50 flex items-center justify-center p-4"
>
    <div x-show="open" x-transition.opacity class="fixed inset-0 bg-navy-900/60" x-on:click="open = false"></div>

    <div
        x-show="open"
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0 scale-95"
        x-transition:enter-end="opacity-100 scale-100"
        class="relative w-full {{ $maxWidthClass }} rounded-2xl bg-white p-6 shadow-xl"
    >
        <div class="mb-4 flex items-center justify-between">
            @if($title)
                <h3 class="text-lg font-semibold text-navy-900">{{ $title }}</h3>
            @endif
            <button type="button" x-on:click="open = false" class="text-navy-400 hover:text-navy-700">&times;</button>
        </div>

        {{ $slot }}
    </div>
</div>
