@props(['variant' => 'primary', 'type' => 'button'])

@php
$base = 'inline-flex items-center justify-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed';
$variants = [
    'primary' => 'bg-accent-500 text-white hover:bg-accent-600 focus:ring-accent-400',
    'secondary' => 'bg-navy-800 text-white hover:bg-navy-700 focus:ring-navy-500',
    'outline' => 'border border-navy-300 text-navy-800 hover:bg-navy-50 focus:ring-navy-300',
    'danger' => 'bg-red-600 text-white hover:bg-red-700 focus:ring-red-400',
    'ghost' => 'text-navy-700 hover:bg-navy-100 focus:ring-navy-300',
];
@endphp

<button {{ $attributes->merge(['type' => $type, 'class' => $base.' '.($variants[$variant] ?? $variants['primary'])]) }}>
    {{ $slot }}
</button>
