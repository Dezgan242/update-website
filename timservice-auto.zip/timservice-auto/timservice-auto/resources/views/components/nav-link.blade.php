@props(['active' => false])

@php
$classes = $active
    ? 'text-accent-500 font-semibold'
    : 'text-navy-700 hover:text-accent-500 transition';
@endphp

<a {{ $attributes->merge(['class' => $classes.' text-sm']) }}>
    {{ $slot }}
</a>
