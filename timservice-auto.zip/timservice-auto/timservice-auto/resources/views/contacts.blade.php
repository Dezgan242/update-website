@extends('layouts.app')

@section('content')
<section class="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-bold text-navy-900">Контакты</h1>

    <div class="mt-8 grid gap-10 lg:grid-cols-2">
        <div>
            <dl class="space-y-4 text-navy-700">
                <div>
                    <dt class="text-sm text-navy-500">Телефон</dt>
                    <dd class="text-lg font-semibold text-navy-900">{{ $contacts['contact_phone'] ?? '' }}</dd>
                </div>
                <div>
                    <dt class="text-sm text-navy-500">Email</dt>
                    <dd class="text-lg font-semibold text-navy-900">{{ $contacts['contact_email'] ?? '' }}</dd>
                </div>
                <div>
                    <dt class="text-sm text-navy-500">Адрес</dt>
                    <dd class="text-lg font-semibold text-navy-900">{{ $contacts['contact_address'] ?? '' }}</dd>
                </div>
                <div>
                    <dt class="text-sm text-navy-500">Режим работы</dt>
                    <dd class="text-lg font-semibold text-navy-900">{{ $contacts['work_hours'] ?? '' }}</dd>
                </div>
            </dl>

            <div class="mt-8 aspect-video overflow-hidden rounded-2xl bg-navy-100">
                @if(!empty($contacts['map_iframe']))
                    {!! $contacts['map_iframe'] !!}
                @else
                    <div class="flex h-full items-center justify-center text-navy-400">Карта появится после настройки в админ-панели</div>
                @endif
            </div>
        </div>

        <x-card>
            <h2 class="mb-4 text-lg font-semibold text-navy-900">Написать нам</h2>

            @if(session('success'))
                <x-alert type="success" class="mb-4">{{ session('success') }}</x-alert>
            @endif

            <form method="POST" action="{{ route('contacts.store') }}" class="space-y-4">
                @csrf
                <input type="text" name="website" tabindex="-1" autocomplete="off" class="hidden" aria-hidden="true">

                <x-input name="name" label="Ваше имя" required />
                <x-input name="email" type="email" label="Email" />
                <x-input name="phone" label="Телефон" />
                <x-textarea name="message" label="Сообщение" required />

                <label class="flex items-start gap-2 text-xs text-navy-500">
                    <input type="checkbox" name="consent_pd" value="1" required class="mt-0.5 rounded border-navy-300">
                    Согласен(-на) на обработку персональных данных
                </label>

                <x-button type="submit" class="w-full">Отправить сообщение</x-button>
            </form>
        </x-card>
    </div>
</section>
@endsection
