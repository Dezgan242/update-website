@component('mail::message')
# Новая заявка №{{ $booking->id }}

@component('mail::table')
| | |
|---|---|
| **Имя** | {{ $booking->name }} |
| **Телефон** | {{ $booking->phone }} |
| **Email** | {{ $booking->email ?? '—' }} |
| **Услуга** | {{ $booking->service->name }} |
| **Дата и время** | {{ $booking->scheduled_at_label }} |
| **Мастер** | {{ $booking->master->name ?? 'не выбран' }} |
| **Автомобиль** | {{ $booking->car_brand }} {{ $booking->car_model }} |
| **Комментарий** | {{ $booking->comment ?? '—' }} |
| **Источник** | {{ $booking->source }} |
@endcomponent

@component('mail::button', ['url' => route('admin.bookings.edit', $booking)])
Открыть заявку в админке
@endcomponent
@endcomponent
