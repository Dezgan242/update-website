@component('mail::message')
# Ваша заявка принята

Здравствуйте, {{ $booking->name }}!

Мы получили вашу заявку на запись №{{ $booking->id }}.

@component('mail::table')
| | |
|---|---|
| **Услуга** | {{ $booking->service->name }} |
| **Дата и время** | {{ $booking->scheduled_at_label }} |
| **Мастер** | {{ $booking->master->name ?? 'будет назначен' }} |
| **Автомобиль** | {{ $booking->car_brand }} {{ $booking->car_model }} |
@endcomponent

Наш менеджер свяжется с вами по телефону {{ $booking->phone }} для подтверждения записи.

@component('mail::button', ['url' => route('home')])
На главную сайта
@endcomponent

Спасибо, что выбрали {{ config('app.name') }}!
@endcomponent
