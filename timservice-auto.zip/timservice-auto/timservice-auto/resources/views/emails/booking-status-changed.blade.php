@component('mail::message')
# Статус вашей заявки изменён

Здравствуйте, {{ $booking->name }}!

Статус вашей заявки №{{ $booking->id }} на услугу «{{ $booking->service->name }}» изменён на:

## {{ $booking->status->label() }}

@if($booking->status->value === 'completed')
Спасибо, что выбрали {{ config('app.name') }}! Будем рады видеть вас снова.
@elseif($booking->status->value === 'cancelled')
Если у вас остались вопросы по отмене — свяжитесь с нами по телефону {{ \App\Models\Setting::get('contact_phone') }}.
@else
Мы свяжемся с вами при необходимости уточнить детали.
@endif

@component('mail::button', ['url' => route('home')])
На главную сайта
@endcomponent
@endcomponent
