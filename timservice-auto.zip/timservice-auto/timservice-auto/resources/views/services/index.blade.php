@extends('layouts.app')

@section('content')
<section class="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-bold text-navy-900">Наши услуги</h1>
    <p class="mt-2 text-navy-600">Выберите категорию и запишитесь на удобное время.</p>

    <div class="mt-8 flex flex-wrap gap-2" x-data>
        <a href="{{ route('services.index') }}" class="rounded-full px-4 py-2 text-sm font-medium {{ $selectedCategory ? 'bg-navy-100 text-navy-700' : 'bg-accent-500 text-white' }}">
            Все
        </a>
        @foreach($categories as $category)
            <a href="{{ route('services.index', ['category' => $category->slug]) }}" class="rounded-full px-4 py-2 text-sm font-medium {{ $selectedCategory === $category->slug ? 'bg-accent-500 text-white' : 'bg-navy-100 text-navy-700 hover:bg-navy-200' }}">
                {{ $category->name }}
            </a>
        @endforeach
    </div>

    @foreach($categories as $category)
        @continue($selectedCategory && $selectedCategory !== $category->slug)
        @continue($category->services->isEmpty())

        <div class="mt-10">
            <h2 class="mb-4 text-xl font-semibold text-navy-900">{{ $category->name }}</h2>
            <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                @foreach($category->services as $service)
                    <x-card class="flex flex-col">
                        <div class="mb-4 aspect-video overflow-hidden rounded-xl bg-navy-100">
                            <img src="{{ $service->cover_url }}" alt="{{ $service->name }}" class="h-full w-full object-cover">
                        </div>
                        <h3 class="text-lg font-semibold text-navy-900">
                            <a href="{{ route('services.show', $service) }}" class="hover:text-accent-500">{{ $service->name }}</a>
                        </h3>
                        <p class="mt-2 flex-1 text-sm text-navy-600">{{ Str::limit($service->description, 90) }}</p>
                        <div class="mt-4 flex items-center justify-between">
                            <span class="font-semibold text-navy-900">от {{ number_format($service->price_from, 0, ',', ' ') }} ₽</span>
                            <a href="{{ route('booking.create', ['service' => $service->slug]) }}" class="rounded-lg bg-accent-500 px-4 py-2 text-sm font-semibold text-white hover:bg-accent-600">Записаться</a>
                        </div>
                    </x-card>
                @endforeach
            </div>
        </div>
    @endforeach
</section>
@endsection
