@extends('layouts.app')

@section('content')
<section class="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:px-8">
    <nav class="mb-6 text-sm text-navy-500">
        <a href="{{ route('services.index') }}" class="hover:text-navy-800">Услуги</a> /
        <span class="text-navy-800">{{ $service->name }}</span>
    </nav>

    <div class="grid gap-10 lg:grid-cols-2">
        <div class="aspect-video overflow-hidden rounded-2xl bg-navy-100">
            <img src="{{ $service->cover_url }}" alt="{{ $service->name }}" class="h-full w-full object-cover">
        </div>

        <div>
            <p class="text-xs font-medium uppercase tracking-wide text-accent-500">{{ $service->category->name }}</p>
            <h1 class="mt-1 text-3xl font-bold text-navy-900">{{ $service->name }}</h1>
            <p class="mt-4 text-navy-700">{{ $service->description }}</p>

            <div class="mt-6 flex items-center gap-6">
                <div>
                    <p class="text-sm text-navy-500">Стоимость</p>
                    <p class="text-xl font-bold text-navy-900">от {{ number_format($service->price_from, 0, ',', ' ') }} ₽</p>
                </div>
                <div>
                    <p class="text-sm text-navy-500">Длительность</p>
                    <p class="text-xl font-bold text-navy-900">{{ $service->duration_minutes }} мин</p>
                </div>
            </div>

            <a href="{{ route('booking.create', ['service' => $service->slug]) }}" class="mt-8 inline-block rounded-lg bg-accent-500 px-6 py-3 text-sm font-semibold text-white hover:bg-accent-600">
                Записаться на услугу
            </a>
        </div>
    </div>

    @if($service->masters->isNotEmpty())
        <div class="mt-14">
            <h2 class="mb-4 text-xl font-semibold text-navy-900">Кто выполняет эту услугу</h2>
            <div class="grid gap-6 sm:grid-cols-3">
                @foreach($service->masters as $master)
                    <x-card class="text-center">
                        <img src="{{ $master->photo_url }}" alt="{{ $master->name }}" class="mx-auto h-20 w-20 rounded-full object-cover">
                        <p class="mt-3 font-semibold text-navy-900">{{ $master->name }}</p>
                        <p class="text-sm text-navy-500">{{ $master->position }}</p>
                    </x-card>
                @endforeach
            </div>
        </div>
    @endif

    @if($reviews->isNotEmpty())
        <div class="mt-14">
            <h2 class="mb-4 text-xl font-semibold text-navy-900">Отзывы об услуге</h2>
            <div class="grid gap-6 sm:grid-cols-2">
                @foreach($reviews as $review)
                    <x-card>
                        <div class="mb-2 flex text-accent-500">
                            @for($i = 0; $i < 5; $i++){{ $i < $review->rating ? '★' : '☆' }}@endfor
                        </div>
                        <p class="text-sm text-navy-700">{{ $review->text }}</p>
                        <p class="mt-3 text-sm font-semibold text-navy-900">{{ $review->name }}</p>
                    </x-card>
                @endforeach
            </div>
        </div>
    @endif

    @if($relatedServices->isNotEmpty())
        <div class="mt-14">
            <h2 class="mb-4 text-xl font-semibold text-navy-900">Похожие услуги</h2>
            <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                @foreach($relatedServices as $related)
                    <a href="{{ route('services.show', $related) }}" class="rounded-xl bg-navy-50 p-4 hover:bg-navy-100">
                        <p class="font-medium text-navy-900">{{ $related->name }}</p>
                        <p class="mt-1 text-sm text-navy-500">от {{ number_format($related->price_from, 0, ',', ' ') }} ₽</p>
                    </a>
                @endforeach
            </div>
        </div>
    @endif
</section>
@endsection
