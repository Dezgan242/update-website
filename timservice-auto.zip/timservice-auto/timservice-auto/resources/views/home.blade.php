@extends('layouts.app')

@section('content')

{{-- Hero --}}
<section class="relative overflow-hidden bg-navy-900 text-white">
    <div class="mx-auto grid max-w-7xl gap-10 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-28">
        <div x-fade-in>
            <p class="mb-3 inline-block rounded-full bg-accent-500/20 px-4 py-1 text-sm font-medium text-accent-300">Автосервис полного цикла</p>
            <h1 class="text-4xl font-extrabold leading-tight sm:text-5xl">Приведём ваш автомобиль в идеальное состояние</h1>
            <p class="mt-4 text-lg text-navy-200">Детейлинг, химчистка, кузовной ремонт, шиномонтаж и диагностика — запись онлайн за 2 минуты.</p>
            <div class="mt-8 flex flex-wrap gap-4">
                <a href="{{ route('booking.create') }}" class="rounded-lg bg-accent-500 px-6 py-3 text-sm font-semibold text-white hover:bg-accent-600">Записаться онлайн</a>
                <a href="{{ route('services.index') }}" class="rounded-lg border border-white/30 px-6 py-3 text-sm font-semibold hover:bg-white/10">Смотреть услуги</a>
            </div>
        </div>
        <div class="flex items-center justify-center" x-fade-in>
            <div class="aspect-square w-full max-w-md rounded-3xl bg-gradient-to-br from-accent-500/30 to-navy-700 ring-1 ring-white/10"></div>
        </div>
    </div>
</section>

{{-- Преимущества --}}
<section class="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
    <div class="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
        @foreach([
            ['title' => 'Опытные мастера', 'text' => 'Средний стаж специалистов — более 8 лет.'],
            ['title' => 'Гарантия качества', 'text' => 'Гарантируем результат на все виды работ.'],
            ['title' => 'Онлайн-запись', 'text' => 'Выберите удобное время за пару кликов.'],
            ['title' => 'Честные цены', 'text' => 'Фиксированная стоимость без скрытых доплат.'],
        ] as $advantage)
            <div class="rounded-2xl bg-navy-50 p-6" x-fade-in>
                <div class="mb-3 h-10 w-10 rounded-lg bg-accent-500"></div>
                <h3 class="font-semibold text-navy-900">{{ $advantage['title'] }}</h3>
                <p class="mt-1 text-sm text-navy-600">{{ $advantage['text'] }}</p>
            </div>
        @endforeach
    </div>
</section>

{{-- Популярные услуги --}}
<section class="bg-navy-50 py-16">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="mb-8 flex items-center justify-between">
            <h2 class="text-2xl font-bold text-navy-900">Популярные услуги</h2>
            <a href="{{ route('services.index') }}" class="text-sm font-semibold text-accent-500 hover:text-accent-600">Все услуги →</a>
        </div>

        <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            @foreach($popularServices as $service)
                <x-card class="flex flex-col" x-fade-in>
                    <div class="mb-4 aspect-video overflow-hidden rounded-xl bg-navy-100">
                        <img src="{{ $service->cover_url }}" alt="{{ $service->name }}" class="h-full w-full object-cover">
                    </div>
                    <p class="text-xs font-medium uppercase tracking-wide text-accent-500">{{ $service->category->name }}</p>
                    <h3 class="mt-1 text-lg font-semibold text-navy-900">{{ $service->name }}</h3>
                    <p class="mt-2 flex-1 text-sm text-navy-600">{{ Str::limit($service->description, 90) }}</p>
                    <div class="mt-4 flex items-center justify-between">
                        <span class="font-semibold text-navy-900">от {{ number_format($service->price_from, 0, ',', ' ') }} ₽</span>
                        <a href="{{ route('booking.create', ['service' => $service->slug]) }}" class="rounded-lg bg-accent-500 px-4 py-2 text-sm font-semibold text-white hover:bg-accent-600">Записаться</a>
                    </div>
                </x-card>
            @endforeach
        </div>
    </div>
</section>

{{-- Отзывы --}}
<section class="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
    <h2 class="mb-8 text-2xl font-bold text-navy-900">Отзывы клиентов</h2>
    <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        @foreach($reviews as $review)
            <x-card x-fade-in>
                <div class="mb-2 flex text-accent-500">
                    @for($i = 0; $i < 5; $i++)
                        <span>{{ $i < $review->rating ? '★' : '☆' }}</span>
                    @endfor
                </div>
                <p class="text-sm text-navy-700">{{ Str::limit($review->text, 140) }}</p>
                <p class="mt-3 text-sm font-semibold text-navy-900">{{ $review->name }}</p>
            </x-card>
        @endforeach
    </div>
</section>

{{-- Форма записи --}}
<section class="bg-navy-900 py-16 text-white">
    <div class="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
        <h2 class="text-2xl font-bold">Готовы записаться?</h2>
        <p class="mt-2 text-navy-200">Оставьте заявку — мы свяжемся с вами для подтверждения.</p>
        <a href="{{ route('booking.create') }}" class="mt-6 inline-block rounded-lg bg-accent-500 px-8 py-3 text-sm font-semibold hover:bg-accent-600">Записаться онлайн</a>
    </div>
</section>

{{-- Карта --}}
<section class="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
    <h2 class="mb-6 text-2xl font-bold text-navy-900">Как нас найти</h2>
    <div class="aspect-video w-full overflow-hidden rounded-2xl bg-navy-100">
        @php $mapIframe = \App\Models\Setting::get('map_iframe'); @endphp
        @if($mapIframe)
            {!! $mapIframe !!}
        @else
            <div class="flex h-full items-center justify-center text-navy-400">Карта будет добавлена в настройках админ-панели</div>
        @endif
    </div>
</section>

@endsection
