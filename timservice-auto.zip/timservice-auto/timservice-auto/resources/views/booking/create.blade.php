@extends('layouts.app')

@section('content')
<section class="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-bold text-navy-900">Онлайн-запись</h1>
    <p class="mt-2 text-navy-600">Заполните форму — мы свяжемся с вами для подтверждения.</p>

    @if(session('success'))
        <x-alert type="success" class="mt-6">{{ session('success') }}</x-alert>
    @endif

    <x-card class="mt-8"
        x-data="bookingForm({
            categories: {{ \Illuminate\Support\Js::from($categories->map(fn($c) => ['id' => $c->id, 'name' => $c->name, 'services' => $c->services->map(fn($s) => ['id' => $s->id, 'name' => $s->name, 'slug' => $s->slug])])) }},
            masters: {{ \Illuminate\Support\Js::from($masters->map(fn($m) => ['id' => $m->id, 'name' => $m->name, 'service_ids' => $m->services->pluck('id')])) }},
            preselectedServiceId: {{ $preselectedService?->id ?? 'null' }},
            slotsUrl: '{{ route('booking.slots') }}',
        })"
    >
        <form method="POST" action="{{ route('booking.store') }}" class="space-y-5">
            @csrf
            <input type="text" name="website" tabindex="-1" autocomplete="off" class="hidden" aria-hidden="true">

            <div class="grid gap-5 sm:grid-cols-2">
                <x-input name="name" label="Ваше имя" required />
                <x-input name="phone" label="Телефон" required placeholder="+7 900 000-00-00" />
            </div>

            <div class="grid gap-5 sm:grid-cols-2">
                <x-input name="email" type="email" label="Email (необязательно)" />
                <div class="grid grid-cols-2 gap-3">
                    <x-input name="car_brand" label="Марка авто" />
                    <x-input name="car_model" label="Модель" />
                </div>
            </div>

            <div class="grid gap-5 sm:grid-cols-2">
                <div>
                    <label class="mb-1.5 block text-sm font-medium text-navy-800">Категория услуги</label>
                    <select x-model="selectedCategoryId" x-on:change="onCategoryChange()" class="block w-full rounded-lg border-navy-200 shadow-sm focus:border-accent-500 focus:ring-accent-500 sm:text-sm">
                        <option value="">Выберите категорию</option>
                        <template x-for="category in categories" :key="category.id">
                            <option :value="category.id" x-text="category.name"></option>
                        </template>
                    </select>
                </div>

                <div>
                    <label class="mb-1.5 block text-sm font-medium text-navy-800">Услуга <span class="text-accent-500">*</span></label>
                    <select name="service_id" x-model="selectedServiceId" x-on:change="onServiceChange()" required class="block w-full rounded-lg border-navy-200 shadow-sm focus:border-accent-500 focus:ring-accent-500 sm:text-sm">
                        <option value="">Сначала выберите категорию</option>
                        <template x-for="service in availableServices" :key="service.id">
                            <option :value="service.id" x-text="service.name"></option>
                        </template>
                    </select>
                    @error('service_id')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
                </div>
            </div>

            <div>
                <label class="mb-1.5 block text-sm font-medium text-navy-800">Мастер (необязательно)</label>
                <select name="master_id" x-model="selectedMasterId" x-on:change="loadSlots()" class="block w-full rounded-lg border-navy-200 shadow-sm focus:border-accent-500 focus:ring-accent-500 sm:text-sm">
                    <option value="">Любой свободный мастер</option>
                    <template x-for="master in availableMasters" :key="master.id">
                        <option :value="master.id" x-text="master.name"></option>
                    </template>
                </select>
            </div>

            <div class="grid gap-5 sm:grid-cols-2">
                <x-input name="booking_date" type="date" label="Дата" required x-model="bookingDate" @change="loadSlots()" :min="date('Y-m-d')" />

                <div>
                    <label class="mb-1.5 block text-sm font-medium text-navy-800">Время <span class="text-accent-500">*</span></label>
                    <select name="booking_time" x-model="bookingTime" required class="block w-full rounded-lg border-navy-200 shadow-sm focus:border-accent-500 focus:ring-accent-500 sm:text-sm">
                        <option value="">— выберите дату и услугу —</option>
                        <template x-for="slot in slots" :key="slot">
                            <option :value="slot" x-text="slot"></option>
                        </template>
                    </select>
                    <p class="mt-1 text-xs text-navy-400" x-show="loadingSlots">Загружаем свободное время…</p>
                    <p class="mt-1 text-xs text-red-500" x-show="!loadingSlots && slots.length === 0 && bookingDate && selectedServiceId">На эту дату свободного времени нет, выберите другую дату.</p>
                    @error('booking_time')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
                </div>
            </div>

            <x-textarea name="comment" label="Комментарий (необязательно)" rows="3" />

            <label class="flex items-start gap-2 text-xs text-navy-500">
                <input type="checkbox" name="consent_pd" value="1" required class="mt-0.5 rounded border-navy-300">
                Согласен(-на) на обработку персональных данных
            </label>

            <x-button type="submit" class="w-full">Записаться</x-button>
        </form>
    </x-card>
</section>

@push('scripts')
<script>
    function bookingForm({ categories, masters, preselectedServiceId, slotsUrl }) {
        return {
            categories,
            masters,
            selectedCategoryId: '',
            selectedServiceId: preselectedServiceId ?? '',
            selectedMasterId: '',
            bookingDate: '',
            bookingTime: '',
            slots: [],
            loadingSlots: false,

            get availableServices() {
                const category = this.categories.find(c => c.id == this.selectedCategoryId);
                return category ? category.services : this.categories.flatMap(c => c.services);
            },

            get availableMasters() {
                if (!this.selectedServiceId) return this.masters;
                return this.masters.filter(m => m.service_ids.includes(Number(this.selectedServiceId)));
            },

            init() {
                if (preselectedServiceId) {
                    const category = this.categories.find(c => c.services.some(s => s.id === preselectedServiceId));
                    if (category) this.selectedCategoryId = category.id;
                }
            },

            onCategoryChange() {
                this.selectedServiceId = '';
                this.slots = [];
            },

            onServiceChange() {
                this.selectedMasterId = '';
                this.loadSlots();
            },

            loadSlots() {
                if (!this.selectedServiceId || !this.bookingDate) {
                    this.slots = [];
                    return;
                }

                this.loadingSlots = true;
                const params = new URLSearchParams({
                    service_id: this.selectedServiceId,
                    date: this.bookingDate,
                });
                if (this.selectedMasterId) params.append('master_id', this.selectedMasterId);

                fetch(`${slotsUrl}?${params.toString()}`)
                    .then(r => r.json())
                    .then(data => { this.slots = data.slots ?? []; })
                    .finally(() => { this.loadingSlots = false; });
            },
        };
    }
</script>
@endpush
@endsection
