@extends('layouts.app')

@section('content')
<section class="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-bold text-navy-900">О нас</h1>

    <div class="mt-6 max-w-3xl text-navy-700">
        <p>ТимСервис Авто работает с 2015 года и специализируется на комплексном уходе за автомобилем: от детейлинга и химчистки до кузовного ремонта и диагностики. За годы работы мы обслужили более 10 000 автомобилей и собрали команду мастеров, которым доверяют наши клиенты.</p>
        <p class="mt-4">Мы используем профессиональное оборудование и сертифицированные материалы, а на все виды работ даём гарантию.</p>
    </div>

    <h2 class="mt-14 mb-6 text-2xl font-bold text-navy-900">Наша команда</h2>
    <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        @foreach($masters as $master)
            <x-card class="text-center">
                <img src="{{ $master->photo_url }}" alt="{{ $master->name }}" class="mx-auto h-24 w-24 rounded-full object-cover">
                <p class="mt-3 font-semibold text-navy-900">{{ $master->name }}</p>
                <p class="text-sm text-accent-500">{{ $master->position }}</p>
                <p class="mt-1 text-sm text-navy-500">Стаж: {{ $master->experience_years }} лет</p>
                @if($master->bio)
                    <p class="mt-2 text-sm text-navy-600">{{ $master->bio }}</p>
                @endif
            </x-card>
        @endforeach
    </div>
</section>
@endsection
