<section>
    <header>
        <h2 class="text-lg font-semibold text-navy-900">Данные профиля</h2>
        <p class="mt-1 text-sm text-navy-500">Обновите имя, email и телефон вашего аккаунта.</p>
    </header>

    <form method="POST" action="{{ route('profile.update') }}" class="mt-6 space-y-4">
        @csrf
        @method('patch')

        <x-input name="name" label="Имя" :value="old('name', $user->name)" required />
        <x-input name="email" type="email" label="Email" :value="old('email', $user->email)" required />
        <x-input name="phone" label="Телефон" :value="old('phone', $user->phone)" />

        @if ($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail())
            <p class="text-sm text-navy-600">
                Ваш email не подтверждён.
                <button form="send-verification" class="font-medium text-accent-500 underline hover:text-accent-600">
                    Отправить письмо ещё раз
                </button>
            </p>
            @if (session('status') === 'verification-link-sent')
                <p class="text-sm font-medium text-green-600">Новая ссылка для подтверждения отправлена на ваш email.</p>
            @endif
        @endif

        <div class="flex items-center gap-4">
            <x-button type="submit">Сохранить</x-button>
            @if (session('status') === 'profile-updated')
                <p class="text-sm text-green-600">Сохранено.</p>
            @endif
        </div>
    </form>

    <form id="send-verification" method="POST" action="{{ route('verification.send') }}">
        @csrf
    </form>
</section>
