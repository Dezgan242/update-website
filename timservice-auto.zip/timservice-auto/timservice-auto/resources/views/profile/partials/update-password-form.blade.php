<section>
    <header>
        <h2 class="text-lg font-semibold text-navy-900">Изменить пароль</h2>
        <p class="mt-1 text-sm text-navy-500">Используйте длинный пароль, чтобы аккаунт оставался защищённым.</p>
    </header>

    <form method="POST" action="{{ route('password.update') }}" class="mt-6 space-y-4">
        @csrf
        @method('put')

        <x-input name="current_password" type="password" label="Текущий пароль" />
        @error('current_password', 'updatePassword')
            <p class="text-sm text-red-600">{{ $message }}</p>
        @enderror

        <x-input name="password" type="password" label="Новый пароль" />
        @error('password', 'updatePassword')
            <p class="text-sm text-red-600">{{ $message }}</p>
        @enderror

        <x-input name="password_confirmation" type="password" label="Подтверждение пароля" />

        <div class="flex items-center gap-4">
            <x-button type="submit">Сохранить</x-button>
            @if (session('status') === 'password-updated')
                <p class="text-sm text-green-600">Пароль обновлён.</p>
            @endif
        </div>
    </form>
</section>
