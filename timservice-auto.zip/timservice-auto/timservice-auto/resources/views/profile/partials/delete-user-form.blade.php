<section x-data="{ confirmOpen: false }">
    <header>
        <h2 class="text-lg font-semibold text-red-700">Удалить аккаунт</h2>
        <p class="mt-1 text-sm text-navy-500">После удаления аккаунта все данные будут безвозвратно удалены.</p>
    </header>

    <button type="button" x-on:click="confirmOpen = true" class="mt-4 rounded-lg bg-red-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-red-700">
        Удалить аккаунт
    </button>

    <div x-show="confirmOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-navy-900/60 p-4">
        <div class="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl" x-on:click.outside="confirmOpen = false">
            <h3 class="text-lg font-semibold text-navy-900">Вы уверены?</h3>
            <p class="mt-2 text-sm text-navy-600">Введите пароль, чтобы подтвердить удаление аккаунта. Это действие необратимо.</p>

            <form method="POST" action="{{ route('profile.destroy') }}" class="mt-4 space-y-4">
                @csrf
                @method('delete')

                <x-input name="password" type="password" label="Пароль" required />
                @error('password', 'userDeletion')
                    <p class="text-sm text-red-600">{{ $message }}</p>
                @enderror

                <div class="flex justify-end gap-3">
                    <x-button variant="ghost" type="button" x-on:click="confirmOpen = false">Отмена</x-button>
                    <x-button variant="danger" type="submit">Удалить аккаунт</x-button>
                </div>
            </form>
        </div>
    </div>
</section>
