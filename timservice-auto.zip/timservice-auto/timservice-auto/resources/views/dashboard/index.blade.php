@extends('layouts.app')

@section('content')
<section class="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:px-8">
    <div class="flex items-center justify-between">
        <h1 class="text-3xl font-bold text-navy-900">Мои заявки</h1>
        <a href="{{ route('booking.create') }}" class="rounded-lg bg-accent-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-accent-600">Новая запись</a>
    </div>

    <div class="mt-8 overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-navy-100">
        <table class="min-w-full divide-y divide-navy-100 text-sm">
            <thead class="bg-navy-50 text-left text-xs uppercase tracking-wide text-navy-500">
                <tr>
                    <th class="px-4 py-3">Дата и время</th>
                    <th class="px-4 py-3">Услуга</th>
                    <th class="px-4 py-3">Мастер</th>
                    <th class="px-4 py-3">Статус</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-navy-100">
                @forelse($bookings as $booking)
                    <tr>
                        <td class="px-4 py-3 text-navy-800">{{ $booking->scheduled_at_label }}</td>
                        <td class="px-4 py-3 text-navy-800">{{ $booking->service->name }}</td>
                        <td class="px-4 py-3 text-navy-600">{{ $booking->master->name ?? '—' }}</td>
                        <td class="px-4 py-3">
                            <x-badge :classes="$booking->status->badgeClasses()">{{ $booking->status->label() }}</x-badge>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" class="px-4 py-8 text-center text-navy-400">У вас пока нет заявок.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-6">{{ $bookings->links() }}</div>
</section>
@endsection
