@extends('layouts.admin')

@section('title', $service->exists ? 'Редактирование услуги' : 'Новая услуга')

@section('content')
<h1 class="mb-6 text-2xl font-bold text-navy-900">{{ $service->exists ? 'Редактирование услуги' : 'Новая услуга' }}</h1>

<x-card class="max-w-3xl">
    <form method="POST" action="{{ $service->exists ? route('admin.services.update', $service) : route('admin.services.store') }}" enctype="multipart/form-data" class="space-y-4">
        @csrf
        @if($service->exists) @method('put') @endif

        <x-select name="category_id" label="Категория" :options="$categories->pluck('name', 'id')" :value="$service->category_id" required />
        <x-input name="name" label="Название" :value="$service->name" required />
        <x-input name="slug" label="Slug (необязательно)" :value="$service->slug" />
        <x-textarea name="description" label="Описание" :value="$service->description" />

        <div class="grid grid-cols-2 gap-4">
            <x-input name="price_from" type="number" step="0.01" label="Цена от, ₽" :value="$service->price_from ?? 0" required />
            <x-input name="duration_minutes" type="number" label="Длительность, мин" :value="$service->duration_minutes ?? 60" required />
        </div>

        <div>
            <label class="mb-1.5 block text-sm font-medium text-navy-800">Обложка</label>
            @if($service->exists && $service->cover_url)
                <img src="{{ $service->cover_url }}" class="mb-2 h-24 w-32 rounded-lg object-cover">
            @endif
            <input type="file" name="cover" accept="image/*" class="block w-full text-sm">
        </div>

        <div>
            <label class="mb-1.5 block text-sm font-medium text-navy-800">Мастера, выполняющие услугу</label>
            <div class="grid grid-cols-2 gap-2 rounded-lg border border-navy-200 p-3 sm:grid-cols-3">
                @foreach($masters as $master)
                    <label class="flex items-center gap-2 text-sm text-navy-700">
                        <input type="checkbox" name="master_ids[]" value="{{ $master->id }}"
                            @checked($service->exists && $service->masters->contains($master->id))
                            class="rounded border-navy-300">
                        {{ $master->name }}
                    </label>
                @endforeach
            </div>
        </div>

        <div class="flex items-center gap-6">
            <label class="flex items-center gap-2 text-sm text-navy-700">
                <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $service->is_active ?? true)) class="rounded border-navy-300">
                Активна
            </label>
            <label class="flex items-center gap-2 text-sm text-navy-700">
                <input type="checkbox" name="is_popular" value="1" @checked(old('is_popular', $service->is_popular ?? false)) class="rounded border-navy-300">
                Показывать в «Популярных» на главной
            </label>
        </div>

        <x-input name="sort_order" type="number" label="Порядок сортировки" :value="$service->sort_order ?? 0" />

        <hr class="border-navy-100">
        <p class="text-sm font-medium text-navy-700">SEO</p>
        <x-input name="meta_title" label="Meta title" :value="$service->meta_title" />
        <x-textarea name="meta_description" label="Meta description" :value="$service->meta_description" rows="2" />

        <div class="flex gap-3">
            <x-button type="submit">Сохранить</x-button>
            <a href="{{ route('admin.services.index') }}" class="inline-flex items-center justify-center rounded-lg border border-navy-300 px-5 py-2.5 text-sm font-semibold text-navy-800 hover:bg-navy-50">Отмена</a>
        </div>
    </form>
</x-card>
@endsection
