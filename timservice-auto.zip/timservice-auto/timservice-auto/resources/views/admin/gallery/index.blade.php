@extends('layouts.admin')

@section('title', 'Галерея работ')

@section('content')
<div class="flex items-center justify-between">
    <h1 class="text-2xl font-bold text-navy-900">Галерея работ</h1>
    <a href="{{ route('admin.gallery.create') }}" class="rounded-lg bg-accent-500 px-4 py-2 text-sm font-semibold text-white hover:bg-accent-600">+ Добавить работу</a>
</div>

<div class="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
    @forelse($items as $item)
        <x-card padding="p-4">
            <div class="grid grid-cols-2 gap-1 overflow-hidden rounded-lg">
                <img src="{{ $item->before_url }}" class="aspect-square object-cover" alt="До">
                <img src="{{ $item->after_url }}" class="aspect-square object-cover" alt="После">
            </div>
            <p class="mt-3 font-semibold text-navy-900">{{ $item->title }}</p>
            <p class="text-xs text-navy-500">{{ $item->category?->name ?? 'без категории' }}</p>
            <div class="mt-3 flex gap-3 text-sm">
                <a href="{{ route('admin.gallery.edit', $item) }}" class="font-medium text-accent-500 hover:text-accent-600">Изменить</a>
                <form method="POST" action="{{ route('admin.gallery.destroy', $item) }}" onsubmit="return confirm('Удалить работу?');">
                    @csrf @method('delete')
                    <button type="submit" class="font-medium text-red-500 hover:text-red-600">Удалить</button>
                </form>
            </div>
        </x-card>
    @empty
        <p class="text-navy-400">Работ пока нет.</p>
    @endforelse
</div>

<div class="mt-6">{{ $items->links() }}</div>
@endsection
