@extends('layouts.admin')

@section('title', $item->exists ? 'Редактирование работы' : 'Новая работа')

@section('content')
<h1 class="mb-6 text-2xl font-bold text-navy-900">{{ $item->exists ? 'Редактирование работы' : 'Новая работа' }}</h1>

<x-card class="max-w-2xl">
    <form method="POST" action="{{ $item->exists ? route('admin.gallery.update', $item) : route('admin.gallery.store') }}" enctype="multipart/form-data" class="space-y-4">
        @csrf
        @if($item->exists) @method('put') @endif

        <x-input name="title" label="Название работы" :value="$item->title" required />
        <x-select name="service_category_id" label="Категория" :options="$categories->pluck('name', 'id')" :value="$item->service_category_id" placeholder="Без категории" />
        <x-textarea name="description" label="Описание" :value="$item->description" />

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="mb-1.5 block text-sm font-medium text-navy-800">Фото «До» @if(!$item->exists)<span class="text-accent-500">*</span>@endif</label>
                @if($item->exists && $item->before_url)
                    <img src="{{ $item->before_url }}" class="mb-2 aspect-square w-full rounded-lg object-cover">
                @endif
                <input type="file" name="before_image" accept="image/*" class="block w-full text-sm" {{ $item->exists ? '' : 'required' }}>
            </div>
            <div>
                <label class="mb-1.5 block text-sm font-medium text-navy-800">Фото «После» @if(!$item->exists)<span class="text-accent-500">*</span>@endif</label>
                @if($item->exists && $item->after_url)
                    <img src="{{ $item->after_url }}" class="mb-2 aspect-square w-full rounded-lg object-cover">
                @endif
                <input type="file" name="after_image" accept="image/*" class="block w-full text-sm" {{ $item->exists ? '' : 'required' }}>
            </div>
        </div>

        <label class="flex items-center gap-2 text-sm text-navy-700">
            <input type="checkbox" name="is_published" value="1" @checked(old('is_published', $item->is_published ?? true)) class="rounded border-navy-300">
            Опубликовано на сайте
        </label>

        <x-input name="sort_order" type="number" label="Порядок сортировки" :value="$item->sort_order ?? 0" />

        <div class="flex gap-3">
            <x-button type="submit">Сохранить</x-button>
            <a href="{{ route('admin.gallery.index') }}" class="inline-flex items-center justify-center rounded-lg border border-navy-300 px-5 py-2.5 text-sm font-semibold text-navy-800 hover:bg-navy-50">Отмена</a>
        </div>
    </form>
</x-card>
@endsection
