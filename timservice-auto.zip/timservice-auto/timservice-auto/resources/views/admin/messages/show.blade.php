@extends('layouts.admin')

@section('title', 'Обращение от '.$message->name)

@section('content')
<h1 class="mb-6 text-2xl font-bold text-navy-900">Обращение от {{ $message->name }}</h1>

<x-card class="max-w-2xl">
    <dl class="space-y-3 text-sm">
        <div><dt class="text-navy-500">Имя</dt><dd class="font-medium text-navy-900">{{ $message->name }}</dd></div>
        <div><dt class="text-navy-500">Email</dt><dd class="font-medium text-navy-900">{{ $message->email ?? '—' }}</dd></div>
        <div><dt class="text-navy-500">Телефон</dt><dd class="font-medium text-navy-900">{{ $message->phone ?? '—' }}</dd></div>
        <div><dt class="text-navy-500">Дата</dt><dd class="text-navy-700">{{ $message->created_at->format('d.m.Y H:i') }}</dd></div>
        <div><dt class="text-navy-500">Сообщение</dt><dd class="whitespace-pre-line text-navy-700">{{ $message->message }}</dd></div>
    </dl>

    <a href="{{ route('admin.messages.index') }}" class="mt-6 inline-flex items-center justify-center rounded-lg border border-navy-300 px-5 py-2.5 text-sm font-semibold text-navy-800 hover:bg-navy-50">Назад к списку</a>
</x-card>
@endsection
