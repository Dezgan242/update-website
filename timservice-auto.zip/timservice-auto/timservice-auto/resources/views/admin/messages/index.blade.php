@extends('layouts.admin')

@section('title', 'Обращения с сайта')

@section('content')
<h1 class="mb-6 text-2xl font-bold text-navy-900">Обращения с сайта</h1>

<div class="overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-navy-100">
    <table class="min-w-full divide-y divide-navy-100 text-sm">
        <thead class="bg-navy-50 text-left text-xs uppercase tracking-wide text-navy-500">
            <tr>
                <th class="px-4 py-3">Имя</th>
                <th class="px-4 py-3">Контакты</th>
                <th class="px-4 py-3">Сообщение</th>
                <th class="px-4 py-3">Дата</th>
                <th class="px-4 py-3 text-right">Действия</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-navy-100">
            @forelse($messages as $message)
                <tr class="{{ $message->is_read ? '' : 'bg-accent-50/40 font-medium' }}">
                    <td class="px-4 py-3 text-navy-900">{{ $message->name }}</td>
                    <td class="px-4 py-3 text-navy-600">{{ $message->phone ?? $message->email ?? '—' }}</td>
                    <td class="px-4 py-3 text-navy-600">{{ Str::limit($message->message, 60) }}</td>
                    <td class="px-4 py-3 text-navy-500">{{ $message->created_at->format('d.m.Y H:i') }}</td>
                    <td class="px-4 py-3 text-right">
                        <a href="{{ route('admin.messages.show', $message) }}" class="font-medium text-accent-500 hover:text-accent-600">Открыть</a>
                        <form method="POST" action="{{ route('admin.messages.destroy', $message) }}" class="inline" onsubmit="return confirm('Удалить обращение?');">
                            @csrf @method('delete')
                            <button type="submit" class="ml-3 font-medium text-red-500 hover:text-red-600">Удалить</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="5" class="px-4 py-8 text-center text-navy-400">Обращений пока нет.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="mt-6">{{ $messages->links() }}</div>
@endsection
