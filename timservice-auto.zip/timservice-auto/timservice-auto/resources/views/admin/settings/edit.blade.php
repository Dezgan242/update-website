@extends('layouts.admin')

@section('title', 'Настройки сайта')

@section('content')
<h1 class="mb-6 text-2xl font-bold text-navy-900">Настройки сайта</h1>

<form method="POST" action="{{ route('admin.settings.update') }}" class="max-w-3xl space-y-8">
    @csrf @method('put')

    <x-card>
        <h2 class="mb-4 font-semibold text-navy-900">Контакты</h2>
        <div class="space-y-4">
            <x-input name="contact_phone" label="Телефон" :value="$settings['contact_phone'] ?? ''" />
            <x-input name="contact_email" type="email" label="Email" :value="$settings['contact_email'] ?? ''" />
            <x-input name="contact_address" label="Адрес" :value="$settings['contact_address'] ?? ''" />
            <x-input name="work_hours" label="Режим работы" :value="$settings['work_hours'] ?? ''" />
            <x-textarea name="map_iframe" label="Код карты (iframe)" :value="$settings['map_iframe'] ?? ''" rows="3" />
        </div>
    </x-card>

    <x-card>
        <h2 class="mb-4 font-semibold text-navy-900">Социальные сети</h2>
        <div class="space-y-4">
            <x-input name="social_vk" label="Ссылка на VK" :value="$settings['social_vk'] ?? ''" />
            <x-input name="social_telegram" label="Ссылка на Telegram" :value="$settings['social_telegram'] ?? ''" />
            <x-input name="social_whatsapp" label="Номер WhatsApp" :value="$settings['social_whatsapp'] ?? ''" />
        </div>
    </x-card>

    <x-card>
        <h2 class="mb-4 font-semibold text-navy-900">SEO по умолчанию</h2>
        <div class="space-y-4">
            <x-input name="seo_title" label="SEO title" :value="$settings['seo_title'] ?? ''" />
            <x-textarea name="seo_description" label="SEO description" :value="$settings['seo_description'] ?? ''" rows="3" />
        </div>
    </x-card>

    <x-button type="submit">Сохранить настройки</x-button>
</form>
@endsection
