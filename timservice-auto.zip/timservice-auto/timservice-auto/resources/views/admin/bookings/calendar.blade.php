@extends('layouts.admin')

@section('title', 'Календарь записей')

@section('content')
<div
    x-data="calendar({
        eventsUrl: '{{ route('admin.bookings.calendar.events') }}',
        weekStart: '{{ $weekStart->toDateString() }}',
    })"
    x-init="loadEvents()"
>
    <div class="mb-6 flex items-center justify-between">
        <h1 class="text-2xl font-bold text-navy-900">Календарь записей</h1>
        <div class="flex items-center gap-3">
            <a href="{{ route('admin.bookings.calendar', ['week' => $weekStart->copy()->subWeek()->toDateString()]) }}" class="rounded-lg border border-navy-300 px-3 py-1.5 text-sm hover:bg-navy-50">← Пред. неделя</a>
            <span class="text-sm font-medium text-navy-700">{{ $weekStart->format('d.m') }} — {{ $weekStart->copy()->endOfWeek()->format('d.m.Y') }}</span>
            <a href="{{ route('admin.bookings.calendar', ['week' => $weekStart->copy()->addWeek()->toDateString()]) }}" class="rounded-lg border border-navy-300 px-3 py-1.5 text-sm hover:bg-navy-50">След. неделя →</a>
        </div>
    </div>

    <div class="grid grid-cols-1 gap-3 overflow-x-auto sm:grid-cols-7">
        <template x-for="day in days" :key="day.date">
            <div class="min-w-[180px] rounded-xl border border-navy-100 bg-white p-3">
                <p class="mb-2 text-sm font-semibold text-navy-900" x-text="day.label"></p>
                <div class="space-y-2">
                    <template x-for="event in eventsForDay(day.date)" :key="event.id">
                        <a :href="event.edit_url" class="block rounded-lg p-2 text-xs" :class="statusClasses(event.status)">
                            <p class="font-semibold" x-text="event.time"></p>
                            <p x-text="event.title"></p>
                            <p class="opacity-70" x-text="event.master ?? 'мастер не назначен'"></p>
                        </a>
                    </template>
                    <p x-show="eventsForDay(day.date).length === 0" class="text-xs text-navy-300">Нет записей</p>
                </div>
            </div>
        </template>
    </div>
</div>

@push('scripts')
<script>
    function calendar({ eventsUrl, weekStart }) {
        return {
            events: [],
            days: Array.from({ length: 7 }, (_, i) => {
                const d = new Date(weekStart);
                d.setDate(d.getDate() + i);
                const iso = d.toISOString().slice(0, 10);
                return { date: iso, label: d.toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric', month: 'short' }) };
            }),

            loadEvents() {
                fetch(`${eventsUrl}?week=${weekStart}`)
                    .then(r => r.json())
                    .then(data => { this.events = data.events ?? []; });
            },

            eventsForDay(date) {
                return this.events.filter(e => e.date === date).sort((a, b) => a.time.localeCompare(b.time));
            },

            statusClasses(status) {
                return {
                    new: 'bg-blue-50 text-blue-700 hover:bg-blue-100',
                    in_progress: 'bg-orange-50 text-orange-700 hover:bg-orange-100',
                    completed: 'bg-green-50 text-green-700 hover:bg-green-100',
                    cancelled: 'bg-gray-100 text-gray-500 hover:bg-gray-200',
                }[status] ?? 'bg-navy-50 text-navy-700';
            },
        };
    }
</script>
@endpush
@endsection
