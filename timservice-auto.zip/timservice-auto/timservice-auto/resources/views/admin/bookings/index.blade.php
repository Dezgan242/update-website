@extends('layouts.admin')

@section('title', 'Заявки')

@section('content')
<div class="flex items-center justify-between">
    <h1 class="text-2xl font-bold text-navy-900">Заявки на запись</h1>
    <a href="{{ route('admin.bookings.calendar') }}" class="text-sm font-medium text-accent-500 hover:text-accent-600">Открыть календарь →</a>
</div>

<form method="GET" class="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
    <input type="text" name="search" value="{{ request('search') }}" placeholder="Имя или телефон" class="rounded-lg border-navy-200 text-sm shadow-sm focus:border-accent-500 focus:ring-accent-500">

    <select name="status" class="rounded-lg border-navy-200 text-sm shadow-sm focus:border-accent-500 focus:ring-accent-500">
        <option value="">Все статусы</option>
        @foreach($statuses as $value => $label)
            <option value="{{ $value }}" @selected(request('status') === $value)>{{ $label }}</option>
        @endforeach
    </select>

    <select name="service_id" class="rounded-lg border-navy-200 text-sm shadow-sm focus:border-accent-500 focus:ring-accent-500">
        <option value="">Все услуги</option>
        @foreach($services as $service)
            <option value="{{ $service->id }}" @selected(request('service_id') == $service->id)>{{ $service->name }}</option>
        @endforeach
    </select>

    <input type="date" name="date_from" value="{{ request('date_from') }}" class="rounded-lg border-navy-200 text-sm shadow-sm focus:border-accent-500 focus:ring-accent-500">
    <input type="date" name="date_to" value="{{ request('date_to') }}" class="rounded-lg border-navy-200 text-sm shadow-sm focus:border-accent-500 focus:ring-accent-500">

    <div class="sm:col-span-2 lg:col-span-5">
        <x-button type="submit" variant="outline">Применить фильтры</x-button>
        <a href="{{ route('admin.bookings.index') }}" class="ml-2 text-sm text-navy-500 hover:text-navy-800">Сбросить</a>
    </div>
</form>

{{-- Массовые действия: чекбоксы собирают id в Alpine-массив, форма ниже отправляет их скрытыми полями --}}
<div x-data="{ selected: [], bulkStatus: '', bulkAction: 'set_status',
    allIds: {{ $bookings->pluck('id') }},
    toggleAll(checked) { this.selected = checked ? [...this.allIds] : []; },
    toggleOne(id, checked) { checked ? this.selected.push(id) : this.selected = this.selected.filter(i => i !== id); } }" class="mt-6">

    <form method="POST" action="{{ route('admin.bookings.bulk') }}" x-ref="bulkForm" onsubmit="return confirm('Подтвердите массовое действие');">
        @csrf
        <input type="hidden" name="action" :value="bulkAction">
        <input type="hidden" name="status" :value="bulkStatus" x-show="bulkAction === 'set_status'">
        <template x-for="id in selected" :key="id">
            <input type="hidden" name="ids[]" :value="id">
        </template>

        <div class="mb-3 flex flex-wrap items-center gap-3" x-show="selected.length > 0" x-cloak>
            <span class="text-sm text-navy-600" x-text="`Выбрано: ${selected.length}`"></span>

            <select x-model="bulkStatus" class="rounded-lg border-navy-200 text-sm">
                <option value="">— выберите статус —</option>
                @foreach($statuses as $value => $label)
                    <option value="{{ $value }}">{{ $label }}</option>
                @endforeach
            </select>
            <button type="submit" x-on:click="bulkAction = 'set_status'" :disabled="!bulkStatus" class="rounded-lg bg-navy-800 px-3 py-1.5 text-sm text-white hover:bg-navy-700 disabled:opacity-40">
                Сменить статус
            </button>

            <button type="submit" x-on:click="bulkAction = 'delete'" class="rounded-lg bg-red-600 px-3 py-1.5 text-sm text-white hover:bg-red-700">
                Удалить выбранные
            </button>
        </div>
    </form>

    <div class="overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-navy-100">
        <table class="min-w-full divide-y divide-navy-100 text-sm">
            <thead class="bg-navy-50 text-left text-xs uppercase tracking-wide text-navy-500">
                <tr>
                    <th class="px-4 py-3"><input type="checkbox" x-on:change="toggleAll($event.target.checked)"></th>
                    <th class="px-4 py-3">Клиент</th>
                    <th class="px-4 py-3">Услуга</th>
                    <th class="px-4 py-3">Дата и время</th>
                    <th class="px-4 py-3">Мастер</th>
                    <th class="px-4 py-3">Статус</th>
                    <th class="px-4 py-3 text-right">Действия</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-navy-100">
                @forelse($bookings as $booking)
                    <tr>
                        <td class="px-4 py-3">
                            <input type="checkbox" x-on:change="toggleOne({{ $booking->id }}, $event.target.checked)">
                        </td>
                        <td class="px-4 py-3">
                            <p class="font-medium text-navy-900">{{ $booking->name }}</p>
                            <p class="text-xs text-navy-500">{{ $booking->phone }}</p>
                        </td>
                        <td class="px-4 py-3 text-navy-700">{{ $booking->service->name }}</td>
                        <td class="px-4 py-3 text-navy-700">{{ $booking->scheduled_at_label }}</td>
                        <td class="px-4 py-3 text-navy-600">{{ $booking->master->name ?? '—' }}</td>
                        <td class="px-4 py-3">
                            <x-badge :classes="$booking->status->badgeClasses()">{{ $booking->status->label() }}</x-badge>
                        </td>
                        <td class="px-4 py-3 text-right">
                            <a href="{{ route('admin.bookings.edit', $booking) }}" class="font-medium text-accent-500 hover:text-accent-600">Открыть</a>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="7" class="px-4 py-8 text-center text-navy-400">Заявок не найдено.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<div class="mt-6">{{ $bookings->links() }}</div>
@endsection
