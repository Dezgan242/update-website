@extends('layouts.admin')

@section('title', 'Заявка №'.$booking->id)

@section('content')
<h1 class="mb-6 text-2xl font-bold text-navy-900">Заявка №{{ $booking->id }}</h1>

<div class="grid gap-6 lg:grid-cols-3">
    <x-card class="lg:col-span-1">
        <h2 class="mb-3 font-semibold text-navy-900">Данные клиента</h2>
        <dl class="space-y-2 text-sm">
            <div><dt class="text-navy-500">Имя</dt><dd class="font-medium text-navy-900">{{ $booking->name }}</dd></div>
            <div><dt class="text-navy-500">Телефон</dt><dd class="font-medium text-navy-900">{{ $booking->phone }}</dd></div>
            <div><dt class="text-navy-500">Email</dt><dd class="font-medium text-navy-900">{{ $booking->email ?? '—' }}</dd></div>
            <div><dt class="text-navy-500">Автомобиль</dt><dd class="font-medium text-navy-900">{{ $booking->car_brand }} {{ $booking->car_model }}</dd></div>
            <div><dt class="text-navy-500">Услуга</dt><dd class="font-medium text-navy-900">{{ $booking->service->name }}</dd></div>
            <div><dt class="text-navy-500">Комментарий клиента</dt><dd class="text-navy-700">{{ $booking->comment ?? '—' }}</dd></div>
            <div><dt class="text-navy-500">Источник</dt><dd class="text-navy-700">{{ $booking->source }}</dd></div>
        </dl>
    </x-card>

    <x-card class="lg:col-span-2">
        <h2 class="mb-3 font-semibold text-navy-900">Управление заявкой</h2>
        <form method="POST" action="{{ route('admin.bookings.update', $booking) }}" class="space-y-4">
            @csrf @method('put')

            <x-select name="status" label="Статус" :options="$statuses" :value="$booking->status->value" required />
            <x-select name="master_id" label="Мастер" :options="$masters->pluck('name', 'id')" :value="$booking->master_id" placeholder="Не назначен" />

            <div class="grid grid-cols-2 gap-4">
                <x-input name="booking_date" type="date" label="Дата" :value="$booking->booking_date->toDateString()" required />
                <x-input name="booking_time" type="time" label="Время" :value="substr($booking->booking_time, 0, 5)" required />
            </div>

            <x-textarea name="admin_notes" label="Внутренние заметки менеджера" :value="$booking->admin_notes" />

            <div class="flex gap-3">
                <x-button type="submit">Сохранить</x-button>
                <a href="{{ route('admin.bookings.index') }}" class="inline-flex items-center justify-center rounded-lg border border-navy-300 px-5 py-2.5 text-sm font-semibold text-navy-800 hover:bg-navy-50">Назад к списку</a>
            </div>
        </form>

        <form method="POST" action="{{ route('admin.bookings.destroy', $booking) }}" class="mt-4" onsubmit="return confirm('Удалить заявку безвозвратно?');">
            @csrf @method('delete')
            <button type="submit" class="text-sm font-medium text-red-500 hover:text-red-600">Удалить заявку</button>
        </form>
    </x-card>
</div>
@endsection
