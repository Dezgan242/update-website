@extends('layouts.admin')

@section('title', 'Модерация отзывов')

@section('content')
<h1 class="mb-6 text-2xl font-bold text-navy-900">Отзывы</h1>

<div class="mb-4 flex gap-2 text-sm">
    <a href="{{ route('admin.reviews.index') }}" class="rounded-full px-4 py-1.5 {{ !request('status') ? 'bg-accent-500 text-white' : 'bg-navy-100 text-navy-700' }}">Все</a>
    <a href="{{ route('admin.reviews.index', ['status' => 'approved']) }}" class="rounded-full px-4 py-1.5 {{ request('status') === 'approved' ? 'bg-accent-500 text-white' : 'bg-navy-100 text-navy-700' }}">Опубликованные</a>
    <a href="{{ route('admin.reviews.index', ['status' => 'pending']) }}" class="rounded-full px-4 py-1.5 {{ request('status') === 'pending' ? 'bg-accent-500 text-white' : 'bg-navy-100 text-navy-700' }}">На модерации</a>
</div>

<div class="space-y-4">
    @forelse($reviews as $review)
        <x-card>
            <div class="flex items-start justify-between">
                <div>
                    <p class="font-semibold text-navy-900">{{ $review->name }} <span class="ml-2 text-accent-500">{{ str_repeat('★', $review->rating) }}{{ str_repeat('☆', 5 - $review->rating) }}</span></p>
                    @if($review->service)
                        <p class="text-xs uppercase tracking-wide text-navy-400">{{ $review->service->name }}</p>
                    @endif
                    <p class="mt-2 text-sm text-navy-700">{{ $review->text }}</p>
                    <p class="mt-2 text-xs text-navy-400">{{ $review->created_at->format('d.m.Y H:i') }} · {{ $review->phone ?? $review->email ?? 'контакт не указан' }}</p>
                </div>
                <x-badge :classes="$review->is_approved ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'">
                    {{ $review->is_approved ? 'Опубликован' : 'На модерации' }}
                </x-badge>
            </div>

            <div class="mt-3 flex gap-3 text-sm">
                @if(!$review->is_approved)
                    <form method="POST" action="{{ route('admin.reviews.approve', $review) }}">
                        @csrf @method('patch')
                        <button type="submit" class="font-medium text-green-600 hover:text-green-700">Опубликовать</button>
                    </form>
                @else
                    <form method="POST" action="{{ route('admin.reviews.reject', $review) }}">
                        @csrf @method('patch')
                        <button type="submit" class="font-medium text-amber-600 hover:text-amber-700">Скрыть</button>
                    </form>
                @endif
                <form method="POST" action="{{ route('admin.reviews.destroy', $review) }}" onsubmit="return confirm('Удалить отзыв?');">
                    @csrf @method('delete')
                    <button type="submit" class="font-medium text-red-500 hover:text-red-600">Удалить</button>
                </form>
            </div>
        </x-card>
    @empty
        <p class="text-navy-400">Отзывов нет.</p>
    @endforelse
</div>

<div class="mt-6">{{ $reviews->links() }}</div>
@endsection
