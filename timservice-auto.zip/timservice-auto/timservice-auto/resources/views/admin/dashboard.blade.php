@extends('layouts.admin')

@section('title', 'Дашборд')

@section('content')
<h1 class="mb-6 text-2xl font-bold text-navy-900">Дашборд</h1>

<div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
    <x-card>
        <p class="text-sm text-navy-500">Заявок сегодня</p>
        <p class="mt-1 text-3xl font-bold text-navy-900">{{ $bookingsToday }}</p>
    </x-card>
    <x-card>
        <p class="text-sm text-navy-500">Заявок за неделю</p>
        <p class="mt-1 text-3xl font-bold text-navy-900">{{ $bookingsThisWeek }}</p>
    </x-card>
    <x-card>
        <p class="text-sm text-navy-500">Заявок за месяц</p>
        <p class="mt-1 text-3xl font-bold text-navy-900">{{ $bookingsThisMonth }}</p>
    </x-card>
    <x-card>
        <p class="text-sm text-navy-500">Выручка за месяц (выполненные)</p>
        <p class="mt-1 text-3xl font-bold text-navy-900">{{ number_format($revenueThisMonth, 0, ',', ' ') }} ₽</p>
    </x-card>
</div>

<div class="mt-6 grid gap-6 lg:grid-cols-3">
    <x-card class="lg:col-span-2">
        <h2 class="mb-4 font-semibold text-navy-900">Заявки за последние 14 дней</h2>
        <canvas id="bookingsChart" height="120"></canvas>
    </x-card>

    <x-card>
        <h2 class="mb-4 font-semibold text-navy-900">Топ-5 услуг</h2>
        <ul class="space-y-3">
            @forelse($topServices as $service)
                <li class="flex items-center justify-between text-sm">
                    <span class="text-navy-700">{{ $service->name }}</span>
                    <span class="font-semibold text-navy-900">{{ $service->bookings_count }}</span>
                </li>
            @empty
                <li class="text-sm text-navy-400">Данных пока нет.</li>
            @endforelse
        </ul>
    </x-card>
</div>

<x-card class="mt-6">
    <h2 class="mb-4 font-semibold text-navy-900">Заявки по статусам</h2>
    <div class="flex flex-wrap gap-3">
        @foreach(\App\Enums\BookingStatus::cases() as $status)
            <x-badge :classes="$status->badgeClasses()">
                {{ $status->label() }}: {{ $statusCounts[$status->value] ?? 0 }}
            </x-badge>
        @endforeach
    </div>
</x-card>

@push('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
    const chartData = @json($chartData);
    new Chart(document.getElementById('bookingsChart'), {
        type: 'line',
        data: {
            labels: chartData.map(d => d.day.slice(5)),
            datasets: [{
                label: 'Заявок',
                data: chartData.map(d => d.total),
                borderColor: '#f97316',
                backgroundColor: 'rgba(249,115,22,0.1)',
                tension: 0.3,
                fill: true,
            }],
        },
        options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } },
    });
</script>
@endpush
@endsection
