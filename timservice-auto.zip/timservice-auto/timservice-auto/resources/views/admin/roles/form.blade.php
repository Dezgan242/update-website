@extends('layouts.admin')

@section('title', $role->exists ? 'Редактирование роли' : 'Новая роль')

@section('content')
<h1 class="mb-6 text-2xl font-bold text-navy-900">{{ $role->exists ? 'Редактирование роли' : 'Новая роль' }}</h1>

<x-card class="max-w-2xl">
    <form method="POST" action="{{ $role->exists ? route('admin.roles.update', $role) : route('admin.roles.store') }}" class="space-y-4">
        @csrf
        @if($role->exists) @method('put') @endif

        <x-input name="name" label="Название роли" :value="$role->name" required />

        <div>
            <label class="mb-1.5 block text-sm font-medium text-navy-800">Права</label>
            <div class="grid grid-cols-2 gap-2 rounded-lg border border-navy-200 p-3">
                @foreach($permissions as $permission)
                    <label class="flex items-center gap-2 text-sm text-navy-700">
                        <input type="checkbox" name="permissions[]" value="{{ $permission->id }}"
                            @checked($role->exists && $role->permissions->contains($permission->id))
                            class="rounded border-navy-300">
                        {{ $permission->name }}
                    </label>
                @endforeach
            </div>
        </div>

        <div class="flex gap-3">
            <x-button type="submit">Сохранить</x-button>
            <a href="{{ route('admin.roles.index') }}" class="inline-flex items-center justify-center rounded-lg border border-navy-300 px-5 py-2.5 text-sm font-semibold text-navy-800 hover:bg-navy-50">Отмена</a>
        </div>
    </form>
</x-card>
@endsection
