@extends('layouts.admin')

@section('title', 'Роли и права')

@section('content')
<div class="flex items-center justify-between">
    <h1 class="text-2xl font-bold text-navy-900">Роли и права</h1>
    <a href="{{ route('admin.roles.create') }}" class="rounded-lg bg-accent-500 px-4 py-2 text-sm font-semibold text-white hover:bg-accent-600">+ Новая роль</a>
</div>

<div class="mt-6 overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-navy-100">
    <table class="min-w-full divide-y divide-navy-100 text-sm">
        <thead class="bg-navy-50 text-left text-xs uppercase tracking-wide text-navy-500">
            <tr>
                <th class="px-4 py-3">Роль</th>
                <th class="px-4 py-3">Прав назначено</th>
                <th class="px-4 py-3">Пользователей</th>
                <th class="px-4 py-3 text-right">Действия</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-navy-100">
            @foreach($roles as $role)
                <tr>
                    <td class="px-4 py-3 font-medium text-navy-900">{{ $role->name }}</td>
                    <td class="px-4 py-3 text-navy-600">{{ $role->permissions_count }}</td>
                    <td class="px-4 py-3 text-navy-600">{{ $role->users_count }}</td>
                    <td class="px-4 py-3 text-right">
                        <a href="{{ route('admin.roles.edit', $role) }}" class="font-medium text-accent-500 hover:text-accent-600">Изменить</a>
                        @unless(in_array($role->name, ['admin', 'manager', 'client']))
                            <form method="POST" action="{{ route('admin.roles.destroy', $role) }}" class="inline" onsubmit="return confirm('Удалить роль?');">
                                @csrf @method('delete')
                                <button type="submit" class="ml-3 font-medium text-red-500 hover:text-red-600">Удалить</button>
                            </form>
                        @endunless
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
