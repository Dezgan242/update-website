@extends('layouts.admin')

@section('title', $category->exists ? 'Редактирование категории' : 'Новая категория')

@section('content')
<h1 class="mb-6 text-2xl font-bold text-navy-900">{{ $category->exists ? 'Редактирование категории' : 'Новая категория' }}</h1>

<x-card class="max-w-2xl">
    <form method="POST" action="{{ $category->exists ? route('admin.categories.update', $category) : route('admin.categories.store') }}" class="space-y-4">
        @csrf
        @if($category->exists) @method('put') @endif

        <x-input name="name" label="Название" :value="$category->name" required />
        <x-input name="slug" label="Slug (необязательно, сгенерируется автоматически)" :value="$category->slug" />
        <x-textarea name="description" label="Описание" :value="$category->description" />
        <x-input name="sort_order" type="number" label="Порядок сортировки" :value="$category->sort_order ?? 0" />

        <label class="flex items-center gap-2 text-sm text-navy-700">
            <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $category->is_active ?? true)) class="rounded border-navy-300">
            Активна (отображается на сайте)
        </label>

        <hr class="border-navy-100">
        <p class="text-sm font-medium text-navy-700">SEO</p>
        <x-input name="meta_title" label="Meta title" :value="$category->meta_title" />
        <x-textarea name="meta_description" label="Meta description" :value="$category->meta_description" rows="2" />

        <div class="flex gap-3">
            <x-button type="submit">Сохранить</x-button>
            <a href="{{ route('admin.categories.index') }}" class="inline-flex items-center justify-center rounded-lg border border-navy-300 px-5 py-2.5 text-sm font-semibold text-navy-800 hover:bg-navy-50">Отмена</a>
        </div>
    </form>
</x-card>
@endsection
