@extends('layouts.admin')

@section('title', 'Категории услуг')

@section('content')
<div class="flex items-center justify-between">
    <h1 class="text-2xl font-bold text-navy-900">Категории услуг</h1>
    <a href="{{ route('admin.categories.create') }}" class="rounded-lg bg-accent-500 px-4 py-2 text-sm font-semibold text-white hover:bg-accent-600">+ Добавить</a>
</div>

<form method="GET" class="mt-4 flex gap-2">
    <input type="text" name="search" value="{{ request('search') }}" placeholder="Поиск по названию" class="w-full max-w-xs rounded-lg border-navy-200 text-sm shadow-sm focus:border-accent-500 focus:ring-accent-500">
    <x-button type="submit" variant="outline">Найти</x-button>
</form>

<div class="mt-6 overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-navy-100">
    <table class="min-w-full divide-y divide-navy-100 text-sm">
        <thead class="bg-navy-50 text-left text-xs uppercase tracking-wide text-navy-500">
            <tr>
                <th class="px-4 py-3">Название</th>
                <th class="px-4 py-3">Услуг</th>
                <th class="px-4 py-3">Активна</th>
                <th class="px-4 py-3 text-right">Действия</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-navy-100">
            @forelse($categories as $category)
                <tr>
                    <td class="px-4 py-3 font-medium text-navy-900">{{ $category->name }}</td>
                    <td class="px-4 py-3 text-navy-600">{{ $category->services_count }}</td>
                    <td class="px-4 py-3">
                        <x-badge :classes="$category->is_active ? 'bg-green-100 text-green-700' : 'bg-gray-200 text-gray-600'">
                            {{ $category->is_active ? 'Да' : 'Нет' }}
                        </x-badge>
                    </td>
                    <td class="px-4 py-3 text-right">
                        <a href="{{ route('admin.categories.edit', $category) }}" class="font-medium text-accent-500 hover:text-accent-600">Изменить</a>
                        <form method="POST" action="{{ route('admin.categories.destroy', $category) }}" class="inline" onsubmit="return confirm('Удалить категорию?');">
                            @csrf @method('delete')
                            <button type="submit" class="ml-3 font-medium text-red-500 hover:text-red-600">Удалить</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="4" class="px-4 py-8 text-center text-navy-400">Категорий пока нет.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="mt-6">{{ $categories->links() }}</div>
@endsection
