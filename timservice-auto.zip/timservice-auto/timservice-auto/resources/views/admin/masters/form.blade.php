@extends('layouts.admin')

@section('title', $master->exists ? 'Редактирование мастера' : 'Новый мастер')

@section('content')
<h1 class="mb-6 text-2xl font-bold text-navy-900">{{ $master->exists ? 'Редактирование мастера' : 'Новый мастер' }}</h1>

<x-card class="max-w-2xl">
    <form method="POST" action="{{ $master->exists ? route('admin.masters.update', $master) : route('admin.masters.store') }}" enctype="multipart/form-data" class="space-y-4">
        @csrf
        @if($master->exists) @method('put') @endif

        <x-input name="name" label="Имя" :value="$master->name" required />
        <x-input name="position" label="Должность / специализация" :value="$master->position" required />
        <x-input name="experience_years" type="number" label="Стаж, лет" :value="$master->experience_years ?? 0" required />
        <x-textarea name="bio" label="О мастере" :value="$master->bio" />

        <div>
            <label class="mb-1.5 block text-sm font-medium text-navy-800">Фото</label>
            @if($master->exists && $master->photo_url)
                <img src="{{ $master->photo_url }}" class="mb-2 h-24 w-24 rounded-full object-cover">
            @endif
            <input type="file" name="photo" accept="image/*" class="block w-full text-sm">
        </div>

        <div>
            <label class="mb-1.5 block text-sm font-medium text-navy-800">Какие услуги выполняет</label>
            <div class="grid grid-cols-2 gap-2 rounded-lg border border-navy-200 p-3 sm:grid-cols-3">
                @foreach($services as $service)
                    <label class="flex items-center gap-2 text-sm text-navy-700">
                        <input type="checkbox" name="service_ids[]" value="{{ $service->id }}"
                            @checked($master->exists && $master->services->contains($service->id))
                            class="rounded border-navy-300">
                        {{ $service->name }}
                    </label>
                @endforeach
            </div>
        </div>

        <label class="flex items-center gap-2 text-sm text-navy-700">
            <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $master->is_active ?? true)) class="rounded border-navy-300">
            Активен (отображается на сайте)
        </label>

        <x-input name="sort_order" type="number" label="Порядок сортировки" :value="$master->sort_order ?? 0" />

        <div class="flex gap-3">
            <x-button type="submit">Сохранить</x-button>
            <a href="{{ route('admin.masters.index') }}" class="inline-flex items-center justify-center rounded-lg border border-navy-300 px-5 py-2.5 text-sm font-semibold text-navy-800 hover:bg-navy-50">Отмена</a>
        </div>
    </form>
</x-card>
@endsection
