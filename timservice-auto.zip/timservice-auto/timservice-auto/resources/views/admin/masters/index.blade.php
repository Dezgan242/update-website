@extends('layouts.admin')

@section('title', 'Мастера')

@section('content')
<div class="flex items-center justify-between">
    <h1 class="text-2xl font-bold text-navy-900">Мастера</h1>
    <a href="{{ route('admin.masters.create') }}" class="rounded-lg bg-accent-500 px-4 py-2 text-sm font-semibold text-white hover:bg-accent-600">+ Добавить</a>
</div>

<form method="GET" class="mt-4 flex gap-2">
    <input type="text" name="search" value="{{ request('search') }}" placeholder="Поиск по имени" class="w-full max-w-xs rounded-lg border-navy-200 text-sm shadow-sm focus:border-accent-500 focus:ring-accent-500">
    <x-button type="submit" variant="outline">Найти</x-button>
</form>

<div class="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
    @forelse($masters as $master)
        <x-card class="flex items-center gap-4">
            <img src="{{ $master->photo_url }}" class="h-16 w-16 rounded-full object-cover">
            <div class="flex-1">
                <p class="font-semibold text-navy-900">{{ $master->name }}</p>
                <p class="text-sm text-navy-500">{{ $master->position }}</p>
                <div class="mt-2 flex gap-3 text-sm">
                    <a href="{{ route('admin.masters.edit', $master) }}" class="font-medium text-accent-500 hover:text-accent-600">Изменить</a>
                    <form method="POST" action="{{ route('admin.masters.destroy', $master) }}" onsubmit="return confirm('Удалить мастера?');">
                        @csrf @method('delete')
                        <button type="submit" class="font-medium text-red-500 hover:text-red-600">Удалить</button>
                    </form>
                </div>
            </div>
        </x-card>
    @empty
        <p class="text-navy-400">Мастеров пока нет.</p>
    @endforelse
</div>

<div class="mt-6">{{ $masters->links() }}</div>
@endsection
