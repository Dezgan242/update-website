@extends('layouts.admin')

@section('title', $user->exists ? 'Редактирование пользователя' : 'Новый пользователь')

@section('content')
<h1 class="mb-6 text-2xl font-bold text-navy-900">{{ $user->exists ? 'Редактирование пользователя' : 'Новый пользователь' }}</h1>

<x-card class="max-w-xl">
    <form method="POST" action="{{ $user->exists ? route('admin.users.update', $user) : route('admin.users.store') }}" class="space-y-4">
        @csrf
        @if($user->exists) @method('put') @endif

        <x-input name="name" label="Имя" :value="$user->name" required />
        <x-input name="email" type="email" label="Email" :value="$user->email" required />
        <x-input name="phone" label="Телефон" :value="$user->phone" />
        <x-input name="password" type="password" :label="$user->exists ? 'Новый пароль (оставьте пустым, если без изменений)' : 'Пароль'" :required="!$user->exists" />
        <x-select name="role" label="Роль" :options="$roles->pluck('name', 'name')" :value="$user->roles->first()?->name" required />

        <div class="flex gap-3">
            <x-button type="submit">Сохранить</x-button>
            <a href="{{ route('admin.users.index') }}" class="inline-flex items-center justify-center rounded-lg border border-navy-300 px-5 py-2.5 text-sm font-semibold text-navy-800 hover:bg-navy-50">Отмена</a>
        </div>
    </form>
</x-card>
@endsection
