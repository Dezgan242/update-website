@extends('layouts.admin')

@section('title', 'Пользователи')

@section('content')
<div class="flex items-center justify-between">
    <h1 class="text-2xl font-bold text-navy-900">Пользователи</h1>
    <a href="{{ route('admin.users.create') }}" class="rounded-lg bg-accent-500 px-4 py-2 text-sm font-semibold text-white hover:bg-accent-600">+ Добавить</a>
</div>

<form method="GET" class="mt-4 flex gap-2">
    <input type="text" name="search" value="{{ request('search') }}" placeholder="Имя или email" class="w-full max-w-xs rounded-lg border-navy-200 text-sm shadow-sm focus:border-accent-500 focus:ring-accent-500">
    <x-button type="submit" variant="outline">Найти</x-button>
</form>

<div class="mt-6 overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-navy-100">
    <table class="min-w-full divide-y divide-navy-100 text-sm">
        <thead class="bg-navy-50 text-left text-xs uppercase tracking-wide text-navy-500">
            <tr>
                <th class="px-4 py-3">Имя</th>
                <th class="px-4 py-3">Email</th>
                <th class="px-4 py-3">Роль</th>
                <th class="px-4 py-3 text-right">Действия</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-navy-100">
            @forelse($users as $user)
                <tr>
                    <td class="px-4 py-3 font-medium text-navy-900">{{ $user->name }}</td>
                    <td class="px-4 py-3 text-navy-600">{{ $user->email }}</td>
                    <td class="px-4 py-3"><x-badge>{{ $user->roles->pluck('name')->join(', ') ?: '—' }}</x-badge></td>
                    <td class="px-4 py-3 text-right">
                        <a href="{{ route('admin.users.edit', $user) }}" class="font-medium text-accent-500 hover:text-accent-600">Изменить</a>
                        @if($user->id !== auth()->id())
                            <form method="POST" action="{{ route('admin.users.destroy', $user) }}" class="inline" onsubmit="return confirm('Удалить пользователя?');">
                                @csrf @method('delete')
                                <button type="submit" class="ml-3 font-medium text-red-500 hover:text-red-600">Удалить</button>
                            </form>
                        @endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="4" class="px-4 py-8 text-center text-navy-400">Пользователей не найдено.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="mt-6">{{ $users->links() }}</div>
@endsection
