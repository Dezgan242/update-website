<?php

// Конфиг для адреса уведомлений администратора о заявках/отзывах.
// Вынесен отдельным файлом, чтобы не трогать сгенерированный Laravel'ем config/mail.php.
return [
    'admin_notification_email' => env('ADMIN_NOTIFICATION_EMAIL', 'admin@example.com'),
];
